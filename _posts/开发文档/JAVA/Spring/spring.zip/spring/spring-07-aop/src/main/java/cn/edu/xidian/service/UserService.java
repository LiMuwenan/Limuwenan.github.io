package cn.edu.xidian.service;

public interface UserService {
    public void add();
    public void delete();
    public void update();
    public void query();
}
