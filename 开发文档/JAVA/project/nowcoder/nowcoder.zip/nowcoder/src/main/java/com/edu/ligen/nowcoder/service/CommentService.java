package com.edu.ligen.nowcoder.service;

import com.edu.ligen.nowcoder.entity.Comment;

import java.util.List;

public interface CommentService {

    /**
     * 根据实体类型查询到所有帖子
     * @param entityType 实体类型：课程、帖子、用户评论
     * @param offset 偏置
     * @param limit 分页
     * @return
     */
    List<Comment> selectCommentsByEntity(int entityType, int entityId , int offset, int limit);

    /**
     * 根据评论类型查询总共有多少条评论
     * @param entityType 实体类型
     * @param entityId 该类型的id
     * @return
     */
    int selectCommentRows(int entityType,int entityId);


    /**
     * 添加评论
     * @param comment
     * @return
     */
    int insertComment(Comment comment);

    /**
     * 根据id查询
     */
    Comment selectCommentById(int id);
}
