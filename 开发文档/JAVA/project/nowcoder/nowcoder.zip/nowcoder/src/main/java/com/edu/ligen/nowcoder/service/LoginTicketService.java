package com.edu.ligen.nowcoder.service;

import com.edu.ligen.nowcoder.entity.LoginTicket;

import java.util.Map;

public interface LoginTicketService {

    //根据凭证找出所有信息
    LoginTicket selectByTicket(String ticket);

    //插入新凭证
    int insertLoginTicket(LoginTicket loginTicket);

    //更新凭证相关信息
    int updateLoginTicket(String ticket, int status);

    /**
     * 登录验证业务
     * @param username 用户名
     * @param password 用户密码
     * @param expiredSeconds 过期时间，单位秒
     * @return
     */
    Map<String,Object> login(String username,String password,long expiredSeconds);


    //删除凭证
    //真正的工程开发很少删除数据，只会让其失效
    int deleteLoginTicket(String ticket);
}
