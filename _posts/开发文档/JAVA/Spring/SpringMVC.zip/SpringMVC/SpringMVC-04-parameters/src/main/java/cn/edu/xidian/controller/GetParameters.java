package cn.edu.xidian.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

@Controller
public class GetParameters {
    @RequestMapping("/login")
    public String test1(HttpServletRequest request, Model model){
        model.addAttribute("name",request.getParameter("name"));
        model.addAttribute("pwd",request.getParameter("pwd"));
        return "test";
    }
}
