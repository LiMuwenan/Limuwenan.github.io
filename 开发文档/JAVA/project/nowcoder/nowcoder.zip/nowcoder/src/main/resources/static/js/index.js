// $(function(){
// 	$("#publishBtn").click(publish);
// });

function publish() {
	$("#publishModal").modal("hide");

	// //发送ajax请求之前，将CSRF设置到消息头中
	// var token = $("meta[name='_csrf']").attr("content");//获得meta标签name为_csrf的content属性值
	// var header = $("meta[name='_csrf_header']").attr("content");
	// $(document).ajaxSend(function(e,xhr,options){
	// 	xhr.setRequestHeader(header,token);//key-value
	// });

	//获取标题和内容
	var content = $("#message-text").val();
	var title = $("#recipient-name").val();
	$.post({
		url:CONTEXT_PATH+"/discuss/add",
		data:{"content":content,"title":title},
		success:function (data){
			data=$.parseJSON(data);
			//在提示框中显示返回的消息
			$("#hintBody").text(data.msg);
			//显示提示框
			$("#hintModal").modal("show");
			//2秒后自动隐藏
			setTimeout(function(){
				$("#hintModal").modal("hide");
				if(data.code==0){
					window.location.reload();
				}
			}, 2000);
		}
	});

}