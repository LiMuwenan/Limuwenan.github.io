package com.edu.ligen.nowcoder.service;

import java.util.List;
import java.util.Map;

public interface FollowService {

    /**
     * 关注某个实体
     * @param userId
     * @param entityType
     * @param entityId
     */
    void follow(int userId,int entityType,int entityId);

    /**
     * 取消关注某个实体
     * @param userId
     * @param entityType
     * @param entityId
     */
    void unfollow(int userId,int entityType,int entityId);


    /**
     * 查询该用户关注的实体数量
     * @param userId
     * @param entityType
     * @return
     */
    long selectFolloweeCount(int userId,int entityType);

    /**
     * 查询该实体的粉丝数量
     * @param entityType
     * @param entityId
     * @return
     */
    long selectFollowerCount(int entityType,int entityId);

    /**
     * 查询该用户是否关注该实体
     * @param userId
     * @param entityType
     * @param entityId
     * @return
     */
    boolean isFollowed(int userId,int entityType,int entityId);

    /**
     * 查询某个用户关注了谁
     * @param userId 用户id
     * @param offset 分页条件
     * @param limit 分页条件
     * @return
     */
    List<Map<String,Object>> selectFollowees(int userId,int offset,int limit);

    /**
     * 查询某个用户的关注者
     * @param userId 用户id
     * @param offset 分页条件
     * @param limit 分页条件
     * @return
     */
    List<Map<String,Object>> selectFollowers(int userId,int offset,int limit);

}
