package com.edu.ligen.nowcoder.util;

public class RedisKeyUtil {

    private static final String SPLIT = ":";

    private static final String PREFIX_ENTITY_LIKE = "like:entity";
    private static final String PREFIX_USER_LIKE = "like:user";
    private static final String PREFIX_FOLLOWEE = "followee";
    private static final String PREFIX_FOLLOWER = "follower";

    private static final String PREFIX_KAPTCHA = "kaptcha";
    private static final String PREFIX_LOGIN_TICKET = "login:ticket";

    private static final String PREFIX_USER = "user";

    private static final String PREFIX_UV = "uv";
    private static final String PREFIX_DAU = "dau";

    private static final String PREFIX_POST = "post";

    /**
     * 对某个实体（帖子，评论，回复）的点赞
     * like:entity:entityType:entityId -> set(userId)
     * 存userId可以知道是哪些人点了赞
     *
     * @param entityType
     * @param entityId
     * @return
     */
    public static String getEntityLikeKey(int entityType, int entityId) {
        StringBuilder sb = new StringBuilder();
        sb.append(PREFIX_ENTITY_LIKE)
                .append(SPLIT)
                .append(entityType)
                .append(SPLIT)
                .append(entityId);
        return sb.toString();
    }

    /**
     * 对哪个对象进行了操作（点赞、关注等），不是当前登录用户
     * like:user -> set(userId)
     *
     * @param userId
     * @return 关于该用户的key
     */
    public static String getUserLikeKey(int userId) {
        StringBuilder sb = new StringBuilder();
        sb.append(PREFIX_USER_LIKE)
                .append(SPLIT)
                .append(userId);
        return sb.toString();
    }

    /**
     * 某个用户关注的实体
     * followee:userId:entityType -> zset(entityId,now)
     *
     * @param userId     关注者
     * @param entityType 实体类型
     * @return
     */
    public static String getFolloweeKey(int userId, int entityType) {
        StringBuilder sb = new StringBuilder();
        sb.append(PREFIX_FOLLOWEE)
                .append(SPLIT)
                .append(userId)
                .append(SPLIT)
                .append(entityType);
        return sb.toString();
    }

    /**
     * 某个实体拥有的粉丝
     * follower:entityType:entityId -> zet(userId,now)
     *
     * @param entityType
     * @param entityId
     * @return
     */
    public static String getFollowerKey(int entityType, int entityId) {
        StringBuilder sb = new StringBuilder();
        sb.append(PREFIX_FOLLOWER)
                .append(SPLIT)
                .append(entityType)
                .append(SPLIT)
                .append(entityId);
        return sb.toString();
    }

    /**
     * 生成一个验证码key
     *
     * @param owner 用户未登录，使用随机的字符串来验证用户，放在cookie中
     * @return
     */
    public static String getKaptchaKey(String owner) {
        StringBuilder sb = new StringBuilder();
        sb.append(PREFIX_KAPTCHA)
                .append(SPLIT)
                .append(owner);
        return sb.toString();
    }

    /**
     * 获得一个登录凭证key
     *
     * @param ticket
     * @return
     */
    public static String getLoginTicketKey(String ticket) {
        StringBuilder sb = new StringBuilder();
        sb.append(PREFIX_LOGIN_TICKET)
                .append(SPLIT)
                .append(ticket);
        return sb.toString();
    }

    /**
     * 获得一个用户的key
     *
     * @param userId
     * @return
     */
    public static String getUserKey(int userId) {
        StringBuilder sb = new StringBuilder();
        sb.append(PREFIX_USER)
                .append(SPLIT)
                .append(userId);
        return sb.toString();
    }

    /**
     * 获取单日的uv key
     *
     * @param date
     * @return
     */
    public static String getUVKey(String date) {
        StringBuilder sb = new StringBuilder();
        sb.append(PREFIX_UV)
                .append(SPLIT)
                .append(date);
        return sb.toString();
    }

    /**
     * 区间uv key
     * @return
     */
    public static String getUVKey(String startDate, String endDate) {
        StringBuilder sb = new StringBuilder();
        sb.append(PREFIX_UV)
                .append(SPLIT)
                .append(startDate)
                .append(SPLIT)
                .append(endDate);
        return sb.toString();
    }

    /**
     * 获取单日 dau key
     * @param date
     * @return String
     */
    public static String getDAUKey(String date){
        StringBuilder sb = new StringBuilder();
        sb.append(PREFIX_DAU)
                .append(SPLIT)
                .append(date);
        return sb.toString();
    }

    /**
     * 区间dau key
     * @return
     */
    public static String getDAUKey(String startDate, String endDate) {
        StringBuilder sb = new StringBuilder();
        sb.append(PREFIX_DAU)
                .append(SPLIT)
                .append(startDate)
                .append(SPLIT)
                .append(endDate);
        return sb.toString();
    }

    /**
     * 统计帖子分数key
     * @return
     */
    public static String getPostScoreKey() {
        StringBuilder sb = new StringBuilder();
        sb.append(PREFIX_POST)
                .append(SPLIT)
                .append("score");
        return sb.toString();
    }
}
