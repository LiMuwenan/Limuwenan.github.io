package cn.edu.xidian.domain;

public class Dog {
    public void speak(){
        System.out.println("wang");
    }
}
