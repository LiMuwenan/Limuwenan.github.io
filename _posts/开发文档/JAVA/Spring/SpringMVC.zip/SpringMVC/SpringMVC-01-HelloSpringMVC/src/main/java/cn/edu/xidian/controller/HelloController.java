package cn.edu.xidian.controller;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HelloController implements Controller {
    @Override
    public ModelAndView handleRequest(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws Exception {
        //模型与视图
        ModelAndView mv = new ModelAndView();

        //封装信息
        mv.addObject("msg","HelloSpringMVC");

        //设置视图名称
        mv.setViewName("hello");//WEB-ING/jsp/hello.jsp（这是项目路径，不是访问路径）

        return mv;
    }
}
