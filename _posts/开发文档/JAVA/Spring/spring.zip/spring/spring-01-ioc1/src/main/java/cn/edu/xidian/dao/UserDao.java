package cn.edu.xidian.dao;

public interface UserDao {
    void getUser();
}
