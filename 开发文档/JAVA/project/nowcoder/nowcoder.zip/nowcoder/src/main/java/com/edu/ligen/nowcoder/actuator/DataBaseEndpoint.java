package com.edu.ligen.nowcoder.actuator;

import com.edu.ligen.nowcoder.util.CommunityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

@Component
@Endpoint(id = "database")//该自定义端点的id，通过这个id访问
public class DataBaseEndpoint {

    private static final Logger logger = LoggerFactory.getLogger(DataBaseEndpoint.class);

    @Autowired
    private DataSource dataSource;
    Connection conn;
    @ReadOperation//通过get请求访问
    public String checkConnection(){

        try {
            conn = dataSource.getConnection();
            return CommunityUtils.getJSONString(0,"获取链接成功");
        } catch (SQLException throwables) {
            logger.error("获取链接失败"+throwables.getMessage());
            return CommunityUtils.getJSONString(1,"获取链接失败");
        }finally {
            try {
                conn.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
    }
}
