import cn.edu.xidian.domain.User;
import cn.edu.xidian.mapper.UserMapper;
import cn.edu.xidian.untils.MybaitsUntils;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

import java.util.List;

public class MyTest {

    @Test
    public void test(){
        SqlSession sqlsession = MybaitsUntils.getSqlSession();

        UserMapper userMapper = sqlsession.getMapper(UserMapper.class);

        List<User> users = userMapper.getUserList();

        for (int i = 0; i < users.size(); i++) {
            System.out.println(users.get(i));
        }
    }
}
