package com.edu.ligen.nowcoder.event;

import com.alibaba.fastjson.JSONObject;
import com.edu.ligen.nowcoder.entity.Event;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

@Component
public class EventProducer {

    @Autowired
    private KafkaTemplate kafkaTemplate;

    //处理事件
    public void fireEvent(Event event){
        //将事件发送到指定得主题
        kafkaTemplate.send(event.getTopic(), JSONObject.toJSON(event).toString());
    }
}
