package cn.edu.xidian.domain;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import javax.annotation.Resource;

public class Person {

    @Resource
    private Cat cat;
    @Resource
    private Dog dog3;
    @Resource(name="dog44")
    private Dog dog4;

    private String name;

    public Cat getCat() {
        return cat;
    }

    public void setCat(Cat cat) {
        this.cat = cat;
    }

    public Dog getDog3() {
        return dog3;
    }

    public void setDog3(Dog dog3) {
        this.dog3 = dog3;
    }

    public Dog getDog4() {
        return dog4;
    }

    public void setDog4(Dog dog4) {
        this.dog4 = dog4;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Person{" +
                "cat=" + cat +
                ", dog3=" + dog3 +
                ", dog4=" + dog4 +
                ", name='" + name + '\'' +
                '}';
    }
}
