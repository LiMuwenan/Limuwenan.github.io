package com.edu.ligen.nowcoder.service.impl;

import com.edu.ligen.nowcoder.dao.UserMapper;
import com.edu.ligen.nowcoder.entity.User;
import com.edu.ligen.nowcoder.service.UserService;
import com.edu.ligen.nowcoder.util.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import javax.servlet.http.HttpSession;
import java.util.*;
import java.util.concurrent.TimeUnit;

@Service
public class UserServiceImpl implements UserService, CommunityConstant {

    //邮件客户端
    @Autowired
    private MailClientUtils mailClient;

    //模板引擎，用于发送模板邮件
    @Autowired
    private TemplateEngine templateEngine;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private HostHolder hostHolder;

    //服务端邮件地址
    @Value("${community.path.domain}")
    private String domain;

    //项目路径
    @Value("${server.servlet.context-path}")
    private String contextPath;

    @Autowired
    private RedisTemplate redisTemplate;


    @Override
    public Map<String, Object> register(User user) {
        Map<String,Object> map = new HashMap<>();

        //用户对象不能为空
        if(user == null){
            map.put("usernameMsg","用户名不能为空");
            map.put("passwordMsg","密码不能为空");
            map.put("emailMsg","邮箱不能为空");
            throw new IllegalArgumentException("参数不能为空");
        }

        //判断用户名
        if(StringUtils.isBlank(user.getUsername())){
            map.put("usernameMsg","用户名不能为空");
            return map;
        }
        //判断密码
        if(StringUtils.isBlank(user.getPassword())){
            map.put("passwordMsg","密码不能为空");
            return map;
        }
        //判断邮箱
        if(StringUtils.isBlank(user.getEmail())){
            map.put("emailMsg","邮箱不能为空");
            return map;
        }

        //验证邮箱用户名是否已经存在
        User u = userMapper.selectByUsername(user.getUsername());
        if(u!=null){
            map.put("usernameMsg","该用户名已经存在");
            return map;
        }
        u = userMapper.selectByEmail(user.getEmail());
        if(u!=null){
            map.put("emailMsg","该邮箱已被注册");
            return map;
        }

        //注册用户，加盐加密
        user.setSalt(CommunityUtils.generateUUID().substring(0,5));//将UUID截取5位
        user.setPassword(CommunityUtils.md5(user.getPassword()+user.getSalt()));
        user.setType(0);//新用户位普通用户
        user.setStatus(0);//新用户未激活
        user.setActivationCode(CommunityUtils.generateUUID());//生成激活码
        user.setHeaderUrl(String.format("http://images.nowcoder.com/head/%dt.png",new Random().nextInt(1000)));
        user.setCreateTime(new Date());
        userMapper.insertUser(user);

        //发送激活邮件模板邮件
        Context context = new Context();

        //http://localhost:8080/community/activation/101/code
        String url = domain + contextPath + "/activation/" + user.getId() + "/" + user.getActivationCode();
        context.setVariable("activeUrl",url);
        context.setVariable("username",user.getUsername());

        String content = templateEngine.process("mail/activation.html", context);
        mailClient.sendMail(user.getEmail(),"激活邮件",content);


        return map;
    }

    @Override
    public int activation(int userId, String activationCode) {
        User user = selectById(userId);
        //激活失败
        if(user==null){
            return ACTIVATION_FAILED;
        }else if(user.getStatus()== ACTIVATION_FAILED && user.getActivationCode().equals(activationCode)){
            //激活成功
            clearCache(userId);
            userMapper.updateStatus(user.getId(),ACTIVATION_SUCCESS);
            return ACTIVATION_SUCCESS;
        }else if(user.getStatus()==ACTIVATION_SUCCESS) {
            //重复激活
            return ACTIVATION_REPEAT;
        }
        return ACTIVATION_FAILED;
    }

    @Override
    public int sendResetEmail(String email,HttpSession session) {
        User user = userMapper.selectByEmail(email);
        if(user==null)
            return 0;

        int verifycode = new Random().nextInt(899999) + 100000;

        session.setAttribute("verifycode",verifycode);
        session.setAttribute("verifycodeCreateTime",new Date(System.currentTimeMillis()));
        String url = domain + contextPath + "/forget";
        Context context = new Context();
        context.setVariable("username",user.getUsername());
        context.setVariable("verifycode",verifycode);
        context.setVariable("url",url);
        String content = templateEngine.process("mail/forget.html", context);
        mailClient.sendMail(email,"找回密码",content);

        return 1;
    }

    @Override
    public int resetPassword(String email, String verifycode, String password, HttpSession session) {
        Date currentDate = new Date();
        Date createDate = (Date) session.getAttribute("verifycodeCreateTime");

        //没发验证码 或 五分钟超时，验证码失效
        if(createDate!= null && currentDate.getTime()-createDate.getTime() > FIVE_MINUTE_MILLIS){
            return VERIFYCODE_OVERTIME;
        }
        //验证验证码
        String tmpSessionCode = session.getAttribute("verifycode").toString();
        if(!verifycode.equals(tmpSessionCode)){
            //验证码错误
            return VERIFYCODE_ERROR;
        }

        User user = userMapper.selectByEmail(email);
        password = CommunityUtils.md5(password + user.getSalt());
        clearCache(user.getId());
        userMapper.updatePassword(user.getId(),password);

        return VERIFYCODE_COORECT;
    }

    @Override
    public Map<String, Object> resetPassword(String oldPassword, String newPassword) {
        Map<String,Object> map = new HashMap<>();
        if(StringUtils.isBlank(oldPassword)){
            map.put("oldPasswordMsg","旧密码不合法");
            return map;
        }
        if(StringUtils.isBlank(newPassword)){
            map.put("newPasswordMsg","新密码不合法");
            return map;
        }
        //从已登录的信息中拿到user
        User user = hostHolder.getValue();
        //密码错误
        if(!user.getPassword().equals(CommunityUtils.md5(oldPassword+user.getSalt()))){
            map.put("oldPasswordMsg","旧密码输入有误");
            return map;
        }

        //设置了新密码
        clearCache(user.getId());
        userMapper.updatePassword(user.getId(), CommunityUtils.md5(newPassword + user.getSalt()));

        return null;
    }

    @Override
    public User selectById(int id) {
//        return userMapper.selectById(id);
        User user = getCache(id);
        if(user == null){
            user = initCache(id);
        }
        return user;
    }

    @Override
    public User selectByUsername(String username) {
        return userMapper.selectByUsername(username);
    }

    @Override
    public User selectByEmail(String email) {
        return userMapper.selectByEmail(email);
    }

    @Override
    public int insertUser(User user) {
        return userMapper.insertUser(user);
    }

    @Override
    public int updateStatus(int id, int status) {
        clearCache(id);
        return userMapper.updateStatus(id,status);
    }

    @Override
    public int updateHeader(int id, String headerUrl) {
        clearCache(id);
        return userMapper.updateHeader(id,headerUrl);
    }

    @Override
    public int updatePassword(int id, String password) {
        clearCache(id);
        return userMapper.updatePassword(id,password);
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities(int userId) {
        User user = this.selectById(userId);
        List<GrantedAuthority> list = new ArrayList<>();
        list.add(new GrantedAuthority() {
            @Override
            public String getAuthority() {
                switch(user.getType()){
                    case 1:
                        return AUTHORITY_ADMIN;
                    case 2:
                        return AUTHORITY_MODERATOR;
                    default:
                        return AUTHORITY_USER;
                }
            }
        });
        return list;
    }

    //    1.优先从缓存中取值
    private User getCache(int userId){
        String userKey = RedisKeyUtil.getUserKey(userId);
        return (User) redisTemplate.opsForValue().get(userKey);
    }
//    2.取不到时初始化缓存数据
    private User initCache(int userId){
        User user = userMapper.selectById(userId);
        String userKey = RedisKeyUtil.getUserKey(userId);
        redisTemplate.opsForValue().set(userKey,user,3600, TimeUnit.SECONDS);//3600秒缓存过期
        return user;
    }
//    3.数据变更时清除缓存数据，避免多线程错误
    private void clearCache(int userId){
        String userKey = RedisKeyUtil.getUserKey(userId);
        redisTemplate.delete(userKey);
    }
}
