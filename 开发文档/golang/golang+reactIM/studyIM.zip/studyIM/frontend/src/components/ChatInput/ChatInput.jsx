import React, {Component} from "react";
import './ChatInput.scss'

class ChatInput extends Component {
    constructor(props) {
        super(props);
        this.send = this.send.bind(this)
        this.state = {}
    }

    render() {
        console.log("渲染一次ChatInput")
        return (
            <div className="ChatInput">
                <input onKeyDown={this.send} placeholder="Type a message...Hit enter to send"/>
            </div>
        )
    }

    send = (event) => {
        console.log("还没回车")
        if (event.keyCode === 13) {
            this.props.handleSendMsg(event.target.value)
            this.props.onChatHistoryUpdate(event.target.value)
            event.target.value = ""
        }
    }
}

export default ChatInput