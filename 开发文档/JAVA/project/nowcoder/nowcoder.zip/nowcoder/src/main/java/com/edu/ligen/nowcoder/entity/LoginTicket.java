package com.edu.ligen.nowcoder.entity;

import java.util.Date;

public class LoginTicket {

    /**
     * `id` int(11) NOT NULL AUTO_INCREMENT,
     *   `user_id` int(11) NOT NULL,
     *   `ticket` varchar(45) NOT NULL,
     *   `status` int(11) DEFAULT '0' COMMENT '0-有效; 1-无效;',
     *   `expired` timestamp NOT NULL,
     */

    private int id;
    private int userId;
    private String ticket;
    private int status;//0有效，1无效
    private Date expired;//过期时间

    public LoginTicket() {
    }

    public LoginTicket(int id, int userId, String ticket, int status, Date expired) {
        this.id = id;
        this.userId = userId;
        this.ticket = ticket;
        this.status = status;
        this.expired = expired;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getTicket() {
        return ticket;
    }

    public void setTicket(String ticket) {
        this.ticket = ticket;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public Date getExpired() {
        return expired;
    }

    public void setExpired(Date expired) {
        this.expired = expired;
    }

    @Override
    public String toString() {
        return "LoginTicket{" +
                "id=" + id +
                ", userId=" + userId +
                ", ticket='" + ticket + '\'' +
                ", status=" + status +
                ", expired=" + expired +
                '}';
    }
}
