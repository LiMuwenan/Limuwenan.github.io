import React, {Component} from "react";
import Header from '../Header/Header'
import ChatHistory from '../ChatHistory/ChatHistory'
import ChatInput from '../ChatInput/ChatInput'
import './Web.scss'

export var socket = new WebSocket("ws://localhost:8080/ws")

class Web extends Component {
    constructor(props) {
        super(props);
        this.childRef = React.createRef()
        this.ChatHistoryUpdate = this.ChatHistoryUpdate.bind(this);
    }

    // 前端更新数据
    ChatHistoryUpdate(msg) {
        this.childRef.current.Update(msg)
    }

    //挂在connect
    componentDidMount() {
        this.connect()
    }

    // ws向后端发消息
    sendMsg(msg) {
        console.log("sending msg:", msg)
        socket.send(msg)
    }

    // websocket连接
    connect() {
        console.log("Attempting Connection ...")

        // Websocket创建成功触发onopen事件
        socket.onopen = () => {
            console.log("Successful Connected")
        }

        // 客户端收到消息触发该事件
        socket.onmessage = (msg) => {
            console.log("收到消息", msg.data)
            let m = JSON.parse(msg.data)
            if (m.type === 1) {
                this.ChatHistoryUpdate(m.body)
            }
        }

        // 客户端收到关闭连接事件
        socket.onclose = (event) => {
            console.log("Socket close connection:", event)
        }

        // 连接出错
        socket.onerror = error => {
            console.log("Socket error:", error)
        }
    }

    render() {
        console.log("渲染一次Web")
        return (
            <div className="Web">
                <Header />
                <ChatHistory ref={this.childRef}/>
                <ChatInput  handleSendMsg={this.sendMsg} onChatHistoryUpdate={this.ChatHistoryUpdate}/>
            </div>
        )
    }

}

export default Web