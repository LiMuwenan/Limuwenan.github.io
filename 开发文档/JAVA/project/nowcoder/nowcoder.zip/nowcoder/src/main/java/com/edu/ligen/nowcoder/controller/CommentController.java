package com.edu.ligen.nowcoder.controller;

import com.edu.ligen.nowcoder.entity.Comment;
import com.edu.ligen.nowcoder.entity.DiscussPost;
import com.edu.ligen.nowcoder.entity.Event;
import com.edu.ligen.nowcoder.entity.User;
import com.edu.ligen.nowcoder.event.EventProducer;
import com.edu.ligen.nowcoder.service.CommentService;
import com.edu.ligen.nowcoder.service.DiscussPostService;
import com.edu.ligen.nowcoder.util.CommunityConstant;
import com.edu.ligen.nowcoder.util.HostHolder;
import com.edu.ligen.nowcoder.util.RedisKeyUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.Date;

@Controller
@RequestMapping("/comment")
public class CommentController implements CommunityConstant {

    @Autowired
    private CommentService commentService;

    @Autowired
    private HostHolder hostHolder;

    @Autowired
    private EventProducer eventProducer;

    @Autowired
    private DiscussPostService discussPostService;

    @Autowired
    private RedisTemplate redisTemplate;

    @RequestMapping(value = "/add/{discussPostId}", method = RequestMethod.POST)
    public String addComment(@PathVariable("discussPostId") int discussPostId, Comment comment) {
        User user = hostHolder.getValue();
        //user可能为null，后面统一处理
        comment.setUserId(user.getId());
        comment.setStatus(0);
        comment.setCreateTime(new Date());
        commentService.insertComment(comment);

        //处理评论事件
        Event event = new Event()
                .setTopic(TOPIC_COMMENT)
                .setEntityType(comment.getEntityType())
                .setEntityId(comment.getEntityId())
                .setUserId(user.getId())
                .setData("postId", discussPostId);
        //entityUserId需要查出来
        if (comment.getEntityType() == ENTITY_TYPE_POST) {
            //给帖子得评论，从帖子表查询
            DiscussPost target = discussPostService.selectDiscussPost(comment.getEntityId());
            event.setEntityUserId(target.getUserId());

            //将有变化的帖子id加入到redis
            String postScoreKey = RedisKeyUtil.getPostScoreKey();
            redisTemplate.opsForSet().add(postScoreKey, discussPostId);

        } else if (comment.getEntityType() == ENTITY_TYPE_COMMENT) {
            //对评论评论，即回复
            Comment target = commentService.selectCommentById(comment.getEntityId());
            event.setEntityUserId(target.getUserId());
        }
        eventProducer.fireEvent(event);

        return "redirect:/discuss/detail/" + discussPostId;
    }
}
