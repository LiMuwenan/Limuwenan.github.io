package cn.edu.xidian.domain;

public class Hello {
    private String str;
    private String age;

    public Hello(String str, String age) {
        this.str = str;
        this.age = age;
    }

    public String getStr() {
        return str;
    }

    public void setStr(String str) {
        this.str = str;
    }

    @Override
    public String toString() {
        return "Hello{" +
                "str='" + str + '\'' +
                ", age=" + age +
                '}';
    }
}
