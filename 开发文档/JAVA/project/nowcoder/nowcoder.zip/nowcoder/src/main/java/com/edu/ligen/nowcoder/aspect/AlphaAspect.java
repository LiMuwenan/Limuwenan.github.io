package com.edu.ligen.nowcoder.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

//@Component
//@Aspect
public class AlphaAspect {

    /**
     * 定义一个切点
     * 对@Pointcut的定义就是要将这些方法切入到哪些jointpoint
     * pointcut就是一组匹配规则，我该给哪些jointpoint来执行这些方法
     * 对所有service有效
     * 第一个 * 代表返回值
     * 后面的 * 包名
     * (..)参数
     */
    @Pointcut("execution(* com.edu.ligen.nowcoder.service.*.*(..))")
    public void pointcut(){

    }

    @Before("pointcut()")
    public void before(){
        System.out.println("before");
    }

    @After("pointcut()")
    public void after(){
        System.out.println("after");
    }

    /**
     * 返回值之后
     */
    @AfterReturning("pointcut()")
    public void afterReturning(){
        System.out.println("afterReturning");
    }

    @AfterThrowing("pointcut()")
    public void afterThrowing(){
        System.out.println("afterThrowing");
    }

    /**
     * 前后都有
     * @param joinPoint
     * @return
     * @throws Throwable
     */
    @Around("pointcut()")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable{
        System.out.println("around before");
        Object obj = joinPoint.proceed();
        System.out.println("around after");
        return obj;
    }

}
