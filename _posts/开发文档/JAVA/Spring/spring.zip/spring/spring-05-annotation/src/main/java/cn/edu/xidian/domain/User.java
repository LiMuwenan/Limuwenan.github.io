package cn.edu.xidian.domain;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class User {

    @Value("ligen")
    public String name;
}
