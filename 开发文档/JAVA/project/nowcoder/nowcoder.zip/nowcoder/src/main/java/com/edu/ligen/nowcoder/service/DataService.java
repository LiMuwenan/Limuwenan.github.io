package com.edu.ligen.nowcoder.service;

import java.util.Date;

public interface DataService {

    /**
     * 将指定ip记录进uv
     * @param ip
     */
    void recordUV(String ip);

    /**
     * 计算一个时间段内的uv
     * @param startDate
     * @param endDate
     * @return
     */
    long calculateUV(Date startDate,Date endDate);

    /**
     * 将指定用户记录进dau
     * @param userId
     */
    void recordDAU(int userId);

    /**
     * 计算一个时间段内的dau，任何一天活跃就是这个时间段内活跃
     * @param startDate
     * @param endDate
     * @return
     */
    long calculateDAU(Date startDate,Date endDate);
}
