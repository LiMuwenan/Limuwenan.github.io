package com.edu.ligen.nowcoder.config;

import com.edu.ligen.nowcoder.quartz.PostScoreRefreshJob;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.quartz.JobDetailFactoryBean;
import org.springframework.scheduling.quartz.SimpleTriggerFactoryBean;

//配置->数据库->调用
@Configuration
public class QuartzConfig {

    //FactoryBean可简化实例化过程，工厂模式
    //1.通过FactoryBean封装Bean的实例化过程
    //2.将FactoryBean装配到Spring容器中
    //3.将FactoryBean注入给其他Bean
    //4.该Bean得到的是FactoryBean所管理的对象实例

    //配置JobDetail
    //刷新帖子任务
    @Bean
    public JobDetailFactoryBean postScoreRefreshJobDetail(){
        JobDetailFactoryBean factoryBean = new JobDetailFactoryBean();
        factoryBean.setJobClass(PostScoreRefreshJob.class);
        factoryBean.setBeanName("postScoreRefreshJob");//任务名称，不能重复
        factoryBean.setGroup("communityJobGroup");//任务所在组
        factoryBean.setDurability(true);//任务是长久保存吗
        factoryBean.setRequestsRecovery(true);//任务是否可恢复
        return factoryBean;
    }
    //配置Trigger(SimpleTriggerFactoryBean, CronTriggerFactoryBean)
    @Bean
    public SimpleTriggerFactoryBean postScoreRefreshTrigger(JobDetail postScoreRefreshJobDetail){
        SimpleTriggerFactoryBean factoryBean = new SimpleTriggerFactoryBean();
        factoryBean.setJobDetail(postScoreRefreshJobDetail);//触发器对应的任务
        factoryBean.setBeanName("postScoreRefreshTrigger");//任务名称，不能重复
        factoryBean.setGroup("postScoreRefreshTriggerGroup");//任务所在组
        factoryBean.setRepeatInterval(1000 * 60 * 5);//触发间隔，毫秒单位
        factoryBean.setJobDataMap(new JobDataMap());
        return factoryBean;
    }

}
