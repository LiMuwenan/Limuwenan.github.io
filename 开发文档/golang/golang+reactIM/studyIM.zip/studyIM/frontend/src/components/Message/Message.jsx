import React, {Component} from "react";
import './Message.scss'

class Message extends Component {
    constructor(props) {
        super(props);
        this.state={
            message: this.props.message
        }
    }

    render() {
        console.log("渲染一次Message")
        return (
            <div className = "Message">
                {this.state.message}
            </div>
        )
    }
}

export default Message