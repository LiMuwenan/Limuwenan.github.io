package com.edu.ligen.nowcoder.controller;

import com.edu.ligen.nowcoder.entity.DiscussPost;
import com.edu.ligen.nowcoder.entity.Event;
import com.edu.ligen.nowcoder.entity.User;
import com.edu.ligen.nowcoder.event.EventProducer;
import com.edu.ligen.nowcoder.service.LikeService;
import com.edu.ligen.nowcoder.util.CommunityConstant;
import com.edu.ligen.nowcoder.util.CommunityUtils;
import com.edu.ligen.nowcoder.util.HostHolder;
import com.edu.ligen.nowcoder.util.RedisKeyUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.Map;

@Controller
public class LikeController implements CommunityConstant {

    @Autowired
    private LikeService likeService;

    @Autowired
    private HostHolder hostHolder;

    @Autowired
    private EventProducer eventProducer;

    @Autowired
    private RedisTemplate redisTemplate;

    @RequestMapping(value = {"/like"},method = RequestMethod.POST)
    @ResponseBody
    public String like(int entityType,int entityId,int entityUserId,int postId){
        User user = hostHolder.getValue();

        //点赞
        likeService.like(user.getId(),entityType,entityId,entityUserId);
        //统计点赞数量
        long likeCount = likeService.selectEntityLikeCount(entityType, entityId);
        //查询点赞状态
        int likeStatus = likeService.selectEntityLikeStatus(user.getId(), entityType, entityId);

        Map<String,Object> map = new HashMap<>();

        map.put("likeCount",likeCount);
        map.put("likeStatus",likeStatus);

        //处理点赞事件
        //取消赞不用通知
        if(likeStatus==1){
            Event event = new Event()
                    .setTopic(TOPIC_LIKE)
                    .setUserId(user.getId())
                    .setEntityType(entityType)
                    .setEntityId(entityId)
                    .setEntityUserId(entityUserId)
                    .setData("postId",postId);
            eventProducer.fireEvent(event);
        }

        if(entityType == ENTITY_TYPE_POST){
            //只对点赞帖子进行分数计算
            //将有变化的帖子id加入到redis
            String postScoreKey = RedisKeyUtil.getPostScoreKey();
            redisTemplate.opsForSet().add(postScoreKey, postId);
        }


        return CommunityUtils.getJSONString(0,null,map);
    }
}
