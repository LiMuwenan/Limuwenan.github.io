package com.edu.ligen.nowcoder.service.impl;

import com.edu.ligen.nowcoder.dao.UserMapper;
import com.edu.ligen.nowcoder.entity.LoginTicket;
import com.edu.ligen.nowcoder.entity.User;
import com.edu.ligen.nowcoder.service.LoginTicketService;
import com.edu.ligen.nowcoder.util.CommunityUtils;
import com.edu.ligen.nowcoder.util.RedisKeyUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service
public class LoginTicketServiceImpl implements LoginTicketService {

    @Autowired
    private UserMapper userMapper;

//    @Autowired
//    private LoginTicketMapper loginTicketMapper;

    @Autowired
    private RedisTemplate redisTemplate;

    @Override
    public LoginTicket selectByTicket(String ticket) {
//        return loginTicketMapper.selectByTicket(ticket);
        String loginTicketKey = RedisKeyUtil.getLoginTicketKey(ticket);
        return (LoginTicket) redisTemplate.opsForValue().get(loginTicketKey);
    }

    @Override
    public int insertLoginTicket(LoginTicket loginTicket) {
        String loginTicketKey = RedisKeyUtil.getLoginTicketKey(loginTicket.getTicket());
        redisTemplate.opsForValue().set(loginTicketKey,loginTicket);
        return 1;
//        return loginTicketMapper.insertLoginTicket(loginTicket);
    }

    @Override
    public int updateLoginTicket(String ticket, int status) {
//        return loginTicketMapper.updateLoginTicket(ticket, status);
        String loginTicketKey = RedisKeyUtil.getLoginTicketKey(ticket);
        LoginTicket loginTicket = (LoginTicket) redisTemplate.opsForValue().get(loginTicketKey);
        loginTicket.setStatus(status);
        //修改状态
        redisTemplate.opsForValue().set(loginTicketKey,loginTicket);
        return 1;
    }

    @Override
    public Map<String, Object> login(String username, String password,long expiredSeconds) {
        Map<String,Object> map = new HashMap<>();

        //空值处理
        if(StringUtils.isBlank(username) || StringUtils.isEmpty(username)){
            map.put("usernameMsg","用户名不能为空");
            return map;
        }
        if(StringUtils.isBlank(password) || StringUtils.isEmpty(password)){
            map.put("passwordMsg","密码不能为空");
            return map;
        }

        //不为空，判断存在与否，正确与否
        User user = userMapper.selectByUsername(username);
        if(user==null){
            map.put("usernameMsg","该账号不存在");
            return map;
        }
        if(user.getStatus()==0){
            map.put("usernameMsg","该账号未激活");
            return map;
        }
        password = CommunityUtils.md5(password+user.getSalt());
        if(!(user.getPassword().equals(password))){
            //密码不对
            map.put("passwordMsg","账号或密码错误，请核对!");
            return map;
        }


        //账号密码正确，生成登录凭证
        LoginTicket loginTicket = new LoginTicket();
        loginTicket.setTicket(CommunityUtils.generateUUID());
        loginTicket.setStatus(0);
        loginTicket.setUserId(user.getId());
        loginTicket.setExpired(new Date(System.currentTimeMillis()+expiredSeconds*1000));
        //保存登录凭证
//        loginTicketMapper.insertLoginTicket(loginTicket);
        String loginTicketKey = RedisKeyUtil.getLoginTicketKey(loginTicket.getTicket());
        redisTemplate.opsForValue().set(loginTicketKey,loginTicket);//将对象自动序列化




        //凭证生成成功，只将凭证加入map，后来传给客户端
        map.put("ticket",loginTicket.getTicket());

        return map;
    }

    @Override
    public int deleteLoginTicket(String ticket) {
        return 0;
    }
}
