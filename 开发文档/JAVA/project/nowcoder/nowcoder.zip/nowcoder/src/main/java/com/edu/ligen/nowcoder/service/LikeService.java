package com.edu.ligen.nowcoder.service;

public interface LikeService {

    /**
     * 点赞功能
     * @param userId 当前点赞用户
     * @param entityType
     * @param entityId
     * @param entityUserId 被点赞的目标用户
     */
    void like(int userId,int entityType,int entityId,int entityUserId);

    /**
     * 统计某个实体的点赞数量
     * @param entityType
     * @param entityId
     * @return
     */
    long selectEntityLikeCount(int entityType,int entityId);

    /**
     * 查询某个人对某个实体有没有点赞或者点踩
     * @param userId
     * @param entityType
     * @param entityId
     * @return
     */
    int selectEntityLikeStatus(int userId,int entityType,int entityId);

    /**
     * 查询该用户被点赞了多少次
     * @param userId
     * @return
     */
    int selectUserLikeCount(int userId);
}
