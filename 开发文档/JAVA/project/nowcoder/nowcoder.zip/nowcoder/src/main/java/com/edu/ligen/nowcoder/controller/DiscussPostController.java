package com.edu.ligen.nowcoder.controller;

import com.edu.ligen.nowcoder.dao.UserMapper;
import com.edu.ligen.nowcoder.entity.*;
import com.edu.ligen.nowcoder.event.EventProducer;
import com.edu.ligen.nowcoder.service.*;
import com.edu.ligen.nowcoder.util.CommunityConstant;
import com.edu.ligen.nowcoder.util.CommunityUtils;
import com.edu.ligen.nowcoder.util.HostHolder;
import com.edu.ligen.nowcoder.util.RedisKeyUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.*;

@Controller
@RequestMapping(value="/discuss")
public class DiscussPostController implements CommunityConstant {

    @Autowired
    private DiscussPostService discussPostService;

    @Autowired
    private UserService userService;

    @Autowired
    private CommentService commentService;

    @Autowired
    private LikeService likeService;

    @Autowired
    private HostHolder hostHolder;

    @Autowired
    private EventProducer eventProducer;

    @Autowired
    private RedisTemplate redisTemplate;

    /**
     * 响应ajax请求，获取用户发布的帖子并插入数据库
     * @param content
     * @param title
     * @return
     */
    @RequestMapping(value = {"/add"},method = RequestMethod.POST)
    @ResponseBody
    public String addDiscussPost(String content,String title){
        User user = hostHolder.getValue();
        if(user==null){
            return CommunityUtils.getJSONString(403,"您还没有进行登录");
        }
        DiscussPost discussPost = new DiscussPost();
        discussPost.setUserId(user.getId());
        discussPost.setContent(content);
        discussPost.setTitle(title);
        discussPost.setCreateTime(new Date());

        discussPostService.insertDiscussPost(discussPost);
        //默认处理成功，报错情况将来统一处理


        //将有变化的帖子id加入到redis
        String postScoreKey = RedisKeyUtil.getPostScoreKey();
        redisTemplate.opsForSet().add(postScoreKey, discussPost.getId());

        return CommunityUtils.getJSONString(0,"发布成功");
    }

    @RequestMapping(value = {"/detail/{discussPostId}"},method = RequestMethod.GET)
    public String getDiscussPostDetail(Model model, @PathVariable("discussPostId") int postId, Page page){
        //根据路径传回的帖子id查询帖子相关
        DiscussPost post = discussPostService.selectDiscussPost(postId);
        if(post==null){
            model.addAttribute("msg","您查看的帖子可能已经被删除或者存在违规");
            model.addAttribute("target","/index");
        }else{
            //作者
            User user = userService.selectById(post.getUserId());
            model.addAttribute("user",user);
            model.addAttribute("post",post);

            //点赞数量
            long likeCount = likeService.selectEntityLikeCount(ENTITY_TYPE_POST, postId);
            model.addAttribute("likeCount",likeCount);
            //点赞状态
            //用户没有登录也能访问该页面，直接返回0，不用再取user值
            int likeStatus = hostHolder.getValue() == null ? 0 : likeService.selectEntityLikeStatus(hostHolder.getValue().getId(), ENTITY_TYPE_POST, postId);
            model.addAttribute("likeStatus",likeStatus);
            //分页信息
            page.setLimit(5);//每页5个评论
            page.setPath("/discuss/detail/"+postId);//页码对应路径
            page.setRows(post.getCommentCount());//总共评论数
            //查找帖子的评论
            List<Comment> commentList = commentService.selectCommentsByEntity(ENTITY_TYPE_POST, post.getId(), page.getOffset(), page.getLimit());
            //Vo View Object ，用来显示到页面的对象
            List<Map<String,Object>> commentVoList = new ArrayList<>();
            if(commentList!=null){
                //对每条评论进行操作
                for (Comment comment : commentList) {
                    Map<String,Object> commentVo = new HashMap<>();
                    commentVo.put("comment",comment);
                    //页面还要展示用户的信息，评论里只有用户id，所以需要查询出来
                    commentVo.put("user",userService.selectById(comment.getUserId()));

                    //点赞数量
                    likeCount = likeService.selectEntityLikeCount(ENTITY_TYPE_COMMENT, comment.getId());
                    commentVo.put("likeCount",likeCount);
                    //点赞状态
                    //用户没有登录也能访问该页面，直接返回0，不用再取user值
                    likeStatus = hostHolder.getValue() == null ? 0 : likeService.selectEntityLikeStatus(hostHolder.getValue().getId(), ENTITY_TYPE_COMMENT, comment.getId());
                    commentVo.put("likeStatus",likeStatus);

                    //查询回复的列表
                    List<Comment> replyList = commentService.selectCommentsByEntity(ENTITY_TYPE_COMMENT, comment.getId(), 0, Integer.MAX_VALUE);
                    //回复的Vo列表
                    List<Map<String,Object>> replyVoList = new ArrayList<>();
                    if(replyList!=null){
                        for (Comment reply : replyList) {
                            Map<String,Object> replyVo = new HashMap<>();
                            replyVo.put("reply",reply);
                            replyVo.put("user",userService.selectById(reply.getUserId()));
                            //指向性回复
                            User target = reply.getTargetId() == 0 ? null : userService.selectById(reply.getTargetId());
                            replyVo.put("target",target);

                            //点赞数量
                            likeCount = likeService.selectEntityLikeCount(ENTITY_TYPE_COMMENT, reply.getId());
                            replyVo.put("likeCount",likeCount);
                            //点赞状态
                            //用户没有登录也能访问该页面，直接返回0，不用再取user值
                            likeStatus = hostHolder.getValue() == null ? 0 : likeService.selectEntityLikeStatus(hostHolder.getValue().getId(), ENTITY_TYPE_COMMENT, reply.getId());
                            replyVo.put("likeStatus",likeStatus);

                            replyVoList.add(replyVo);
                        }
                    }
                    commentVo.put("replyVo",replyVoList);

                    //查询到评论下的回复的数量
                    int replyCount = commentService.selectCommentRows(ENTITY_TYPE_COMMENT, comment.getId());
                    commentVo.put("replyCount",replyCount);

                    commentVoList.add(commentVo);
                }
            }
            model.addAttribute("comments",commentVoList);
        }

        return "site/discuss-detail";
    }

    //置顶
    @RequestMapping(value = "/top",method = RequestMethod.POST)
    @ResponseBody
    public String setTop(int entityId,int entityUserId){
        DiscussPost post = discussPostService.selectDiscussPost(entityId);//为了方便简单实现
        int row = 0;
        if(post.getType()==POST_TYPE_COMMON){
            row = discussPostService.updateType(entityId, POST_TYPE_TOP);
        }else{
            row = discussPostService.updateType(entityId, POST_TYPE_COMMON);
        }

        //发送系统通知
        Event event = new Event()
                .setTopic(TOPIC_TOP)
                .setUserId(hostHolder.getValue().getId())
                .setEntityType(ENTITY_TYPE_POST)
                .setEntityId(entityId)
                .setEntityUserId(entityUserId);
        eventProducer.fireEvent(event);


        return CommunityUtils.getJSONString(row);
    }

    //加精
    @RequestMapping(value = "/highlight",method = RequestMethod.POST)
    @ResponseBody
    public String setHighlight(int entityId,int entityUserId){
        DiscussPost post = discussPostService.selectDiscussPost(entityId);//为了方便简单实现,直接查询出来状态
        int row = 0;
        if(post.getStatus()==POST_STATUS_COMMON){
            row = discussPostService.updateStatus(entityId, POST_STATUS_HIGHLIGHT);
        }else{
            row = discussPostService.updateStatus(entityId, POST_STATUS_COMMON);
        }


        //发送系统通知
        Event event = new Event()
                .setTopic(TOPIC_HIGHLIGHT)
                .setUserId(hostHolder.getValue().getId())
                .setEntityType(ENTITY_TYPE_POST)
                .setEntityId(entityId)
                .setEntityUserId(entityUserId);
        eventProducer.fireEvent(event);

        //将有变化的帖子id加入到redis
        String postScoreKey = RedisKeyUtil.getPostScoreKey();
        redisTemplate.opsForSet().add(postScoreKey, entityId);

        return CommunityUtils.getJSONString(row);
    }

    //删除
    @RequestMapping(value = "/delete",method = RequestMethod.POST)
    @ResponseBody
    public String deletePost(int entityId,int entityUserId){
        int row = discussPostService.updateStatus(entityId, POST_STATUS_BLACK);

        //发送系统通知
        Event event = new Event()
                .setTopic(TOPIC_DELETE)
                .setUserId(hostHolder.getValue().getId())
                .setEntityType(ENTITY_TYPE_POST)
                .setEntityId(entityId)
                .setEntityUserId(entityUserId);
        eventProducer.fireEvent(event);

        return CommunityUtils.getJSONString(row);
    }

}
