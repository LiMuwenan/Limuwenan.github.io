package cn.edu.xidian.log;

import org.springframework.aop.MethodBeforeAdvice;

import java.lang.reflect.Method;

//前置日志
public class BeforeLog implements MethodBeforeAdvice {

    /**
     * @param method 要执行的目标对象的方法
     * @param objects 参数
     * @param o 目标对象
     * */
    @Override
    public void before(Method method, Object[] objects, Object o) throws Throwable {
        System.out.println("执行了"+o.getClass().getName()+"的"+method.getName());
    }
}
