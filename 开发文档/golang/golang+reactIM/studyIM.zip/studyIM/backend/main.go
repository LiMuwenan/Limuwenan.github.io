package main


import (
	"fmt"
	"net/http"
	ws "studyIM/backend/pkg/websocket"
)

// 定义websocket服务处理函数
func ServeWs(pool *ws.Pool,w http.ResponseWriter, r *http.Request) {
	fmt.Println("websocket endpoint reached")

	// 连接升级
	conn, err := ws.Upgrade(w, r)
	if err != nil {
		fmt.Println("Upgrade error:", err)
		return
	}

	client := &ws.Client{
		Conn: conn,
		Pool: pool,
	}
	pool.Register <- client

	client.Read()
}


func SetupRoutes() {
	pool := ws.NewPool()
	go pool.Start()

	http.HandleFunc("/ws", func(w http.ResponseWriter, r *http.Request) {
		ServeWs(pool, w, r)
	})
}


func main() {
	fmt.Println("Distributed Chat App")
	SetupRoutes()
	http.ListenAndServe(":8080", nil)
}
