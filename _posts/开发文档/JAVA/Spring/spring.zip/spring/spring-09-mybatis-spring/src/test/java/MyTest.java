import cn.edu.xidian.domain.User;
import cn.edu.xidian.mapper.UserMapper;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

public class MyTest {

    @Test
    public void test(){
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        UserMapper userMapper = (UserMapper) context.getBean("userMapper");

        List<User> users = userMapper.getUserList();

        for (User user : users) {
            System.out.println(user.toString());
        }
    }

    @Test
    public void testDao(){
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        UserMapper userMapper = (UserMapper) context.getBean("userMapper2");

        List<User> users = userMapper.getUserList();

        for (User user : users) {
            System.out.println(user.toString());
        }
    }
}
