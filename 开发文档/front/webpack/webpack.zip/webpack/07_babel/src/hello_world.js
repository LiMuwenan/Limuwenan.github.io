function getString() {

    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve('Hello World')
        }, 2000)
    })
}
export default async function helloWorld() {
    let string = await getString()
    console.log(string)
}
