import cn.edu.xidian.domain.Hello;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MyTest {
    public static void main(String[] args) {
        //获取spring上下文对象
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        //我们的对象都在spring中管理
        Hello hello = (Hello) context.getBean("hello3");

        System.out.println(hello.toString());
    }
}
