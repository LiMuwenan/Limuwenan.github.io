import cn.edu.xidian.service.UserService;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MyTest {
    public static void main(String[] args) {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        //动态代理代理的使接口，这里给成了实现类,所以错误
//        UserServiceImpl userService = (UserServiceImpl) context.getBean("userService");

        UserService user = (UserService) context.getBean("userService");

        user.add();
    }
}
