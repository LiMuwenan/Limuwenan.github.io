package com.edu.ligen.nowcoder.dao;

import com.edu.ligen.nowcoder.entity.Message;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface MessageMapper {

    /**
     * 查询当前用户的会话列表，每条会话只显示一条最新的消息
     *
     * @param userId
     * @param offset
     * @param limit
     * @return
     */
    List<Message> selectConversations(int userId, int offset, int limit);

    /**
     * 查询用户当前会话数量
     *
     * @param userId
     * @return
     */
    int selectConversationCount(int userId);

    /**
     * 查询某个会话中的消息
     *
     * @param conversationId
     * @param offset
     * @param limit
     * @return
     */
    List<Message> selectLettersByConversationId(String conversationId, int offset, int limit);

    /**
     * 查询某个会话中的消息数量
     *
     * @param conversationId
     * @return
     */
    int selectLetterCount(String conversationId);

    /**
     * 查询某个会话的未读消息数量
     *
     * @param userId
     * @param conversationId
     * @return
     */
    int selectLetterUnreadCount(int userId, String conversationId);

    /**
     * 新增消息
     *
     * @param message
     * @return
     */
    int insertMessage(Message message);

    /**
     * 修改消息状态，已读或者删除
     *
     * @param ids
     * @param status
     * @return
     */
    int updateMessageStatus(List<Integer> ids, int status);

    /**
     * 查询某主题下最新的通知
     */
    Message selectLatestNotice(int userId, String topic);

    /**
     * 查询某个主题包含的数量
     */
    int selectNoticeCount(int userId, String topic);

    /**
     * 查询未读通知的数量
     */
    int selectUnreadNoticeCount(int userId, String topic);

    /**
     * 查询该主题下的所有通知，支持分页
     */
    List<Message> selectNotices(int userId,String topic,int offset,int limit);
}
