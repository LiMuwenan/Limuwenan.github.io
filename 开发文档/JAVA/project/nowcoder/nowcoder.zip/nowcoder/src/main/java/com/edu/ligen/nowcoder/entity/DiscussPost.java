package com.edu.ligen.nowcoder.entity;

import java.util.Date;

public class DiscussPost {

    /**
     *   `id` int(11) NOT NULL AUTO_INCREMENT, --帖子id
     *   `user_id` varchar(45) DEFAULT NULL, -- 用户id
     *   `title` varchar(100) DEFAULT NULL, -- 帖子标题
     *   `content` text, -- 帖子内容
     *   `type` int(11) DEFAULT NULL COMMENT '0-普通; 1-置顶;', -- 帖子状态
     *   `status` int(11) DEFAULT NULL COMMENT '0-正常; 1-精华; 2-拉黑;', --
     *   `create_time` timestamp NULL DEFAULT NULL, -- 帖子创建时间
     *   `comment_count` int(11) DEFAULT NULL, -- 评论数
     *   `score` double DEFAULT NULL, -- 分数，进行排名
     */

    private int id;
    private int userId;
    private String title;
    private String content;
    private int type; //0普通 1置顶
    private int status; //0普通 1精华 2拉黑
    private Date createTime;
    private int commentCount;
    private double score;

    public DiscussPost(int id, int userId, String title, String content, int type, int status, Date createTime, int commentCount, double score) {
        this.id = id;
        this.userId = userId;
        this.title = title;
        this.content = content;
        this.type = type;
        this.status = status;
        this.createTime = createTime;
        this.commentCount = commentCount;
        this.score = score;
    }

    public DiscussPost() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public int getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(int commentCount) {
        this.commentCount = commentCount;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }

    @Override
    public String toString() {
        return "DiscussPost{" +
                "id=" + id +
                ", userId='" + userId + '\'' +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", type=" + type +
                ", status=" + status +
                ", createTime=" + createTime +
                ", commentCount=" + commentCount +
                ", score=" + score +
                '}';
    }
}
