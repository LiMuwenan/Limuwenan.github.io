package cn.edu.xidian.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

//不用再到springmvc配置文件中注册
@Controller
@RequestMapping(path="/hello")
public class HelloController {

    //直接设置访问路径
    @RequestMapping("/h1")
    public String hello1(Model model){
        //封装数据
        model.addAttribute("msg","springmvc");


        //这个hello就是要访问的页面名称 /WEB-INF/jsp/
        return "hello";//这个return的结果会被视图解析器处理
    }

}
