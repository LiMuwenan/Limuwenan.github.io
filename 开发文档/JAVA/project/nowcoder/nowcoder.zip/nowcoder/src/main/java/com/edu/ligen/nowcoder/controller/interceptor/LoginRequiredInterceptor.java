package com.edu.ligen.nowcoder.controller.interceptor;

import com.edu.ligen.nowcoder.annotation.LoginRequired;
import com.edu.ligen.nowcoder.util.HostHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;

@Deprecated
@Component
public class LoginRequiredInterceptor implements HandlerInterceptor {

    @Autowired
    private HostHolder hostHolder;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if(handler instanceof HandlerMethod){//固定写法，从handler对象中获得是方法的那些
            HandlerMethod handlerMethod = (HandlerMethod) handler;
            Method method =  handlerMethod.getMethod();//获取方法
            LoginRequired loginRequired = method.getAnnotation(LoginRequired.class);//获取注解
            if(loginRequired != null && hostHolder.getValue() == null){
                //在需要登录的请求上没有用户登录过
                response.sendRedirect(request.getContextPath()+"/login");
                return false;
            }

        }
        return true;
    }
}
