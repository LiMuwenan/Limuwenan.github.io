export default function helloWorld() {
    cosole.log('Hello world')
}