package com.edu.ligen.nowcoder.service.impl;

import com.edu.ligen.nowcoder.service.DataService;
import com.edu.ligen.nowcoder.util.RedisKeyUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.connection.RedisStringCommands;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Service
public class DataServiceImpl implements DataService {

    @Autowired
    private RedisTemplate redisTemplate;

    //日期格式
    private SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");


    @Override
    public void recordUV(String ip) {
        String uvKey = RedisKeyUtil.getUVKey(df.format(new Date()));
        redisTemplate.opsForHyperLogLog().add(uvKey,ip);
    }

    @Override
    public long calculateUV(Date startDate, Date endDate) {
        if(startDate==null || endDate==null){
            throw new IllegalArgumentException("参数不能为空");
        }

        //整理该日期范围内的key
        List<String> keyList = new ArrayList<>();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(startDate);
        while(!calendar.getTime().after(endDate)){//不晚于endDate
            String uvKey = RedisKeyUtil.getUVKey(df.format(calendar.getTime()));
            keyList.add(uvKey);
            calendar.add(Calendar.DATE,1);
        }
        //合并数据
        String redisKey = RedisKeyUtil.getUVKey(df.format(startDate),df.format(endDate));
        redisTemplate.opsForHyperLogLog().union(redisKey,keyList.toArray());
        return redisTemplate.opsForHyperLogLog().size(redisKey);
    }

    @Override
    public void recordDAU(int userId) {
        String dauKey = RedisKeyUtil.getDAUKey(df.format(new Date()));
        redisTemplate.opsForValue().setBit(dauKey,userId,true);//类似数组哈希表
    }

    @Override
    public long calculateDAU(Date startDate, Date endDate) {
        if(startDate==null || endDate==null){
            throw new IllegalArgumentException("参数不能为空");
        }

        //整理该日期范围内的key
        List<byte[]> keyList = new ArrayList<>();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(startDate);
        while(!calendar.getTime().after(endDate)){//不晚于endDate
            String dauKey = RedisKeyUtil.getDAUKey(df.format(calendar.getTime()));
            keyList.add(dauKey.getBytes());
            calendar.add(Calendar.DATE,1);
        }
        //进行OR运算，这段时间有一天活跃就是这段时间活跃
        return (long) redisTemplate.execute(new RedisCallback() {
            @Override
            public Object doInRedis(RedisConnection connection) throws DataAccessException {
                String redisKey = RedisKeyUtil.getDAUKey(df.format(startDate),df.format(endDate));
                connection.bitOp(
                        RedisStringCommands.BitOperation.OR,//进行什么运算
                        redisKey.getBytes(),//运算结果存入哪里
                        keyList.toArray(new byte[0][0])//对keyList做运算
                );
                return connection.bitCount(redisKey.getBytes());
            }
        });
    }
}
