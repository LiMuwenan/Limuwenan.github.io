package com.edu.ligen.nowcoder.controller;

import com.edu.ligen.nowcoder.entity.DiscussPost;
import com.edu.ligen.nowcoder.entity.Page;
import com.edu.ligen.nowcoder.entity.User;
import com.edu.ligen.nowcoder.service.DiscussPostService;
import com.edu.ligen.nowcoder.service.LikeService;
import com.edu.ligen.nowcoder.service.UserService;
import com.edu.ligen.nowcoder.util.CommunityConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 访问首页
 */
@Controller
public class IndexController implements CommunityConstant {

    @Autowired
    private UserService userService;

    @Autowired
    private DiscussPostService discussPostService;

    @Autowired
    private LikeService likeService;

    @RequestMapping(value = {"/","/index","/index.html"},method = RequestMethod.GET)
    public String index(Model model, Page page,
                        @RequestParam(name="orderMode",defaultValue = "0") int orderMode ){//如果没有传该参数，默认为零
        //dispathcerServlet会自动的将Page类注入到Model里，我们不需要自己再手动注入
        page.setRows(discussPostService.selectDiscussPostRows(0));
        page.setPath("/index?orderMode=" + orderMode);


        //访问首页，我们需要列出帖子列表，其中包括帖子相关和用户相关，所以要对这两个表都进行查询
        List<DiscussPost> list = discussPostService.selectDiscussPosts(0, page.getOffset(), page.getLimit(),orderMode);//需要查出所有的帖子，每页10条

        List<Map<String,Object>> discussPosts = new ArrayList<>();
        //每条帖子都有发贴用户的userId信息，所以根据这个id去查user表找到这个用户
        for (DiscussPost post : list) {
            Map<String,Object> map = new HashMap<>();
            map.put("post",post);
            User user = userService.selectById(post.getUserId());
            map.put("user",user);
            long likeCount = likeService.selectEntityLikeCount(ENTITY_TYPE_POST, post.getId());
            map.put("likeCount",likeCount);
            discussPosts.add(map);
        }

        model.addAttribute("discussPosts",discussPosts);
        model.addAttribute("orderMode",orderMode);

        return "index";
    }

    /**
     * 服务器发生错误
     * @return
     */
    @RequestMapping(value = {"/error"},method = RequestMethod.GET)
    public String getErrorPage(){
        return "error/500";
    }

    @RequestMapping(value = {"/denied"},method = RequestMethod.GET)
    public String getError404Page(){
        return "error/404";
    }
}
