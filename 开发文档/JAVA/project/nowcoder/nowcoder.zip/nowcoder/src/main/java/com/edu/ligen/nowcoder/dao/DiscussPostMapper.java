package com.edu.ligen.nowcoder.dao;


import com.edu.ligen.nowcoder.entity.DiscussPost;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface DiscussPostMapper {

    /**
     * 查询帖子所有信息，以下参数作为动态sql的条件
     * @param userId 用户id，当在用户页面查询用户发的帖时需要。userId为0则代表查询所有用户的帖子
     * @param orderMode 排序方式
     * @return
     */
    List<DiscussPost> selectDiscussPosts(@Param("userId") int userId, @Param("offset")int offset, @Param("limit") int limit, int orderMode);

    /**
     * 查询某一条帖子的具体信息
     * @param id 帖子id
     * @return
     */
    DiscussPost selectDiscussPost(int id);

    /**
     * 返回总共有多少帖子
     * @param userId
     * @return
     */
    int selectDiscussPostRows(@Param("userId") int userId);

    /**
     * 插入一条帖子信息
     * @param discussPost
     * @return
     */
    int insertDiscussPost(DiscussPost discussPost);

    /**
     * 添加评论后，更新该帖子的评论数量
     * @param id
     * @param commentCount
     * @return
     */
    int updateCommentCount(int id,int commentCount);

    /**
     * 根据id修改帖子类型
     * @param id
     * @param type 0普通 1置顶
     * @return
     */
    int updateType(int id,int type);

    /**
     * 根据id修改帖子类型
     * @param id
     * @param status 0普通 1精华 2拉黑
     * @return
     */
    int updateStatus(int id,int status);


    /**
     * 根据id修改帖子分数
     * @return
     */
    int updateScore(int id,double score);
}
