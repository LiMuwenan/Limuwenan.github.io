package cn.edu.xidian.controller;


import cn.edu.xidian.domain.User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class UserController {

    @RequestMapping(value="/json")
    @ResponseBody
    public String json(){
        User user = new User("ligen","123415");



        return user.toString();
    }
}
