package cn.edu.xidian.dao;

public class UserMysqlImpl implements UserDao{
    public void getUser(){
        System.out.println("MySQL获取数据");
    }
}
