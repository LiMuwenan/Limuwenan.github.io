package com.edu.ligen.nowcoder.service;

import com.edu.ligen.nowcoder.entity.User;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.ui.Model;

import javax.servlet.http.HttpSession;
import java.util.Collection;
import java.util.Map;

public interface UserService {


    /**
     * 注册
     * @param user
     * @return
     */
    Map<String,Object> register(User user);

    /**
     * 激活服务
     * @param userId
     * @param activationCode
     * @return
     */
    int activation(int userId,String activationCode);

    /**
     * 生成验证码，并且发送到邮箱
     * @param session 用来保存验证码
     * @return 0 失败 1 成功
     */
    int sendResetEmail(String email, HttpSession session);

    /**
     * 重置密码
     * @param email
     * @param verifycode
     * @param password
     * @param session
     * @return
     */
    int resetPassword(String email,String verifycode,String password,HttpSession session);

    /**
     * 在设置页面使用旧密码确认来修改密码
     * @param oldPassword
     * @param newPassword
     * @return
     */
    Map<String,Object> resetPassword(String oldPassword, String newPassword);

    User selectById(int id);

    User selectByUsername(String username);

    User selectByEmail(String email);

    int insertUser(User user);

    int updateStatus(int id,int status);

    int updateHeader(int id,String headerUrl);

    int updatePassword(int id,String password);

    /**
     * 获取用户有哪些权限
     * @param userId
     * @return
     */
    Collection<? extends GrantedAuthority> getAuthorities(int userId);

}
