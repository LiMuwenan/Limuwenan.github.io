$(function () {
    $("#topBtn").click(setTop);
    $("#highlightBtn").click(setHighlight);
    $("#deleteBtn").click(setDelete);
});

//置顶
function setTop() {
    $.post({
        url: CONTEXT_PATH + "/discuss/top",
        data: {
            "entityId": $("#postId").val(),
            "entityUserId": $("#userId").val()
        },
        success: function (data) {
            data = $.parseJSON(data);
            if (data.code === 1) {
                if("置顶"===$("#topBtn").text()){
                    $("#topBtn").text("取消置顶");
                }
                // $("#topBtn").attr("disabled", "disabled");
            }else{
                alert(data.msg);
            }
        }
    });
}

//加精
function setHighlight() {
    $.post({
        url: CONTEXT_PATH + "/discuss/highlight",
        data: {
            "entityId": $("#postId").val(),
            "entityUserId": $("#userId").val()
        },
        success: function (data) {
            data = $.parseJSON(data);
            if (data.code === 1) {
                if("加精"===$("#highlightBtn").text()){
                    $("#highlightBtn").text("取消加精");
                }
            }else{
                alert(data.msg);
            }
        }
    });
}

//删除
function setDelete() {
    $.post({
        url: CONTEXT_PATH + "/discuss/delete",
        data: {
            "entityId": $("#postId").val(),
            "entityUserId": $("#userId").val()
        },
        success: function (data) {
            data = $.parseJSON(data);
            if (data.code == 1) {
                location.href = CONTEXT_PATH + "/index";
            }
        }
    });
}


function like(btn, entityType, entityId, entityUserId, postId) {

    $.post({
        url: CONTEXT_PATH + "/like",
        data: {"entityType": entityType, "entityId": entityId, "entityUserId": entityUserId, "postId": postId},
        success: function (data) {
            data = $.parseJSON(data)
            if (data.code == 0) {
                $(btn).children("i").text(data.likeCount);
                $(btn).children("b").text(data.likeStatus == 1 ? '已赞' : '赞');
            } else {
                alert(data.msg);
            }
        }
    })
}