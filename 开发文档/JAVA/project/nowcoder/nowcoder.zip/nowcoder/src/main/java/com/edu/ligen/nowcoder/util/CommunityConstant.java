package com.edu.ligen.nowcoder.util;

/**
 * 常量工具类
 */
public interface CommunityConstant {

    /**
     * 激活失败
     * 未激活
     */
    int ACTIVATION_FAILED = 0;

    /**
     * 激活成功
     */
    int ACTIVATION_SUCCESS = 1;


    /**
     * 重复激活
     */
    int ACTIVATION_REPEAT = 2;

    /**
     * 默认登录时长
     * 12小时
     */
    int DEFAULT_EXPIRED = 3600 * 12;

    /**
     * 记住情况下的登录时长
     * 10天
     */
    int REMEMBER_EXPTRED = 3600 * 24 * 10;

    /**
     * 五分钟
     */
    int FIVE_MINUTE_MILLIS = 5 * 60 * 1000;

    /**
     * 验证码超时
     */
    int VERIFYCODE_OVERTIME = 0;

    /**
     * 验证码错误
     */
    int VERIFYCODE_ERROR = 1;

    /**
     * 验证码正确
     */
    int VERIFYCODE_COORECT = 2;

    /**
     * 帖子，用于查询帖子下的评论
     */
    int ENTITY_TYPE_POST = 1;
    /**
     * 评论，用于查询评论下的回复
     */
    int ENTITY_TYPE_COMMENT = 2;

    /**
     * 用户
     */
    int ENTITY_TYPE_USER = 3;

    /**
     * 主题：评论
     */
    String TOPIC_COMMENT = "comment";

    /**
     * 主题：点赞
     */
    String TOPIC_LIKE = "like";

    /**
     * 主题：关注
     */
    String TOPIC_FOLLOW = "follow";

    /**
     * 主题：置顶
     */
    String TOPIC_TOP = "top";

    /**
     * 主题：加精
     */
    String TOPIC_HIGHLIGHT = "hightlight";

    /**
     * 主题：删帖
     */
    String TOPIC_DELETE = "delete";

    /**
     * 系统用户
     */
    int SYSTEM_USER_ID = 1;

    /**
     * 权限：用户
     */
    String AUTHORITY_USER = "user";

    /**
     * 权限：管理员
     */
    String AUTHORITY_ADMIN = "admin";

    /**
     * 权限：版主
     */
    String AUTHORITY_MODERATOR = "moderator";

    /**
     * 帖子：类型：普通帖
     */
    int POST_TYPE_COMMON = 0;

    /**
     * 帖子：类型：置顶帖
     */
    int POST_TYPE_TOP = 1;

    /**
     * 帖子：状态：普通帖
     */
    int POST_STATUS_COMMON = 0;

    /**
     * 帖子：状态：精华帖
     */
    int POST_STATUS_HIGHLIGHT = 1;

    /**
     * 帖子：状态：拉黑帖
     */
    int POST_STATUS_BLACK = 2;

    /**
     * 帖子排序方式
     */
    int ORDERMODE_HOT = 1;

    int ORDERMODE_COMMON = 0;
}
