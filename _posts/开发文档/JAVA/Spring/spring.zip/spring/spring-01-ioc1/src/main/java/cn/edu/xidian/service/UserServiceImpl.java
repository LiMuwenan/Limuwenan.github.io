package cn.edu.xidian.service;

import cn.edu.xidian.dao.UserDao;
import cn.edu.xidian.dao.UserDaoImpl;

public class UserServiceImpl implements UserService{

//    private UserDao userDao = new UserDaoImpl();//写死之后有新需求很难改
    private UserDao userDao;

    public void setUserDao(UserDao userDao){
        this.userDao = userDao;
    }

    @Override
    public void getUser() {
        userDao.getUser();
    }
}
