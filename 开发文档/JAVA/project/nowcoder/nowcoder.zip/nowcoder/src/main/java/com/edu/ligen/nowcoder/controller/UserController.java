package com.edu.ligen.nowcoder.controller;

import com.edu.ligen.nowcoder.annotation.LoginRequired;
import com.edu.ligen.nowcoder.entity.Comment;
import com.edu.ligen.nowcoder.entity.DiscussPost;
import com.edu.ligen.nowcoder.entity.Page;
import com.edu.ligen.nowcoder.entity.User;
import com.edu.ligen.nowcoder.service.*;
import com.edu.ligen.nowcoder.util.CommunityConstant;
import com.edu.ligen.nowcoder.util.CommunityUtils;
import com.edu.ligen.nowcoder.util.HostHolder;
import com.edu.ligen.nowcoder.util.RedisKeyUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/user")
public class UserController implements CommunityConstant {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @Value("${community.path.domain}")
    private String domain;

    @Value("${community.path.upload}")
    private String uploadPath;

    @Value("${server.servlet.context-path}")
    private String contextPath;

    @Autowired
    private UserService userService;

    @Autowired
    private LikeService likeService;

    @Autowired
    private HostHolder hostHolder;

    @Autowired
    private FollowService followService;

    @Autowired
    private DiscussPostService discussPostService;

    @Autowired
    private CommentService commentService;

    @Autowired
    private RedisTemplate redisTemplate;

    @LoginRequired
    @RequestMapping(value = {"/setting","/setting.html"},method = RequestMethod.GET)
    public String getSettingPage(){
        return "site/setting";
    }

    @RequestMapping(value = {"/profile/{userId}","/profile.html/{userId}"},method = RequestMethod.GET)
    public String getProfilePage(Model model,@PathVariable("userId") int userId){
        int userLikeCount = likeService.selectUserLikeCount(userId);
        User user = userService.selectById(userId);
        //点赞数量
        model.addAttribute("userLikeCount",userLikeCount);
        model.addAttribute("user",user);
        //关注数量
        long followeeCount = followService.selectFolloweeCount(userId, ENTITY_TYPE_USER);
        model.addAttribute("followee",followeeCount);
        //粉丝数量
        long followerCount = followService.selectFollowerCount(ENTITY_TYPE_USER, userId);
        model.addAttribute("follower",followerCount);
        //是否已关注
        boolean isFollowed = false;
        if(hostHolder.getValue()!=null){
            isFollowed = followService.isFollowed(hostHolder.getValue().getId(),ENTITY_TYPE_USER,userId);
        }
        model.addAttribute("isFollowed",isFollowed);
        return "site/profile";
    }


    @LoginRequired
    @RequestMapping(value = "/upload",method = RequestMethod.POST)
    public String upload(MultipartFile headerImage, Model model){
        //文件是否存在
        if(headerImage.isEmpty()){
            model.addAttribute("error","上传的文件不存在");
            return "site/setting";
        }

        //提取文件名称
        String filename = headerImage.getOriginalFilename();
        if(StringUtils.isBlank(filename)){
            model.addAttribute("error","文件名不合法");
            return "/site/setting";
        }
        int dot = filename.lastIndexOf(".");
        if(dot==-1){//文件名没有后缀
            model.addAttribute("error","文件名不合法");
            return "/site/setting";
        }
        String suffix = filename.substring(dot) ;
        if(StringUtils.isBlank(suffix) || (!(".png".equalsIgnoreCase(suffix)) && !(".jpg".equalsIgnoreCase(suffix))&& !(".jpeg".equalsIgnoreCase(suffix)))){
            model.addAttribute("error","文件名不合法");
            return "/site/setting";
        }
        //文件名
        filename = CommunityUtils.generateUUID().substring(0,10) + suffix;
        //访问路径   http://localhost:8080/community/  user/header/xxx.png
        String headerPath = domain + contextPath + "/user/header/" + filename;
        File dest = new File(uploadPath + "/" + filename);//存放路径
        try {
            headerImage.transferTo(dest);//将上传的文件传入到File中，会直接保存到目标位置
        } catch (IOException e) {
            logger.error("上传文件失败" + e.getMessage());
            throw new RuntimeException("上传文件失败，服务器发生异常!",e);
        }

        //上传成功，进行设置
        User user = hostHolder.getValue();
        //这里没登陆上传设置会出错
        if(user==null){
            return "/index";
        }
        user.setHeaderUrl(headerPath);
        int status = userService.updateHeader(user.getId(), user.getHeaderUrl());
        if(status == 1){
            //更新成功
        }else{
            model.addAttribute("headerMsg","头像更新失败");
        }
        return "redirect:/index";
    }

    @RequestMapping(value = "/header/{filename}",method = RequestMethod.GET)
    public void getHeader(@PathVariable("filename") String filename, HttpServletResponse response){
        //服务器存放路径
        filename = uploadPath + "/" + filename;
        //文件后缀
        String suffix = filename.substring(filename.lastIndexOf("."));
        //响应图片
        response.setContentType("image/"+suffix.substring(1));//不要. 有可能出错
        try(
                FileInputStream fis = new FileInputStream(filename);
                OutputStream os = response.getOutputStream();
                ) {
            //图片可能比较大，我们采用按数据块输出
            byte[] buffer = new byte[1024];
            int b = 0;
            while((b = fis.read(buffer)) != -1){
                os.write(buffer,0,b);
            }
        } catch (FileNotFoundException e) {
            logger.error("读取头像失败"+e.getMessage());
        } catch (IOException e) {
            logger.error("输出头像失败"+e.getMessage());
        }

    }

    @RequestMapping(value = "/reset",method = RequestMethod.POST)
    public String resetPassword(String oldPassword,String newPassword,Model model){
        Map<String, Object> map = userService.resetPassword(oldPassword, newPassword);

        if(map!=null){
            //有错误信息
            model.addAttribute("oldPasswordMsg",map.get("oldPasswordMsg"));
            model.addAttribute("newPasswordMsg",map.get("newPasswordMsg"));
            return "/site/setting";
        }else{
            //用户自动退出登录，需要重新上线
            return "redirect:/logout";
        }

    }

    @RequestMapping(value = {"/myPost/{userId}"},method = RequestMethod.GET)
    public String myPost(@PathVariable("userId") int userId, Model model, Page page){
        User user = userService.selectById(userId);
        model.addAttribute("user",user);

        //分页信息
        int postCount = discussPostService.selectDiscussPostRows(userId);
        page.setRows(postCount);
        page.setPath("/user/myPost/" + userId);
        page.setLimit(5);

        //显示帖子
        List<DiscussPost> discussPosts = discussPostService.selectDiscussPosts(userId, page.getOffset(), page.getLimit(),ORDERMODE_COMMON);
        List<Map<String,Object>> discussPostVo = new ArrayList<>();
        if(discussPosts!=null){
            //添加赞信息
            for (DiscussPost discussPost : discussPosts) {
                Map<String,Object> post = new HashMap<>();
                post.put("discussPost",discussPost);
                long likeCount = likeService.selectEntityLikeCount(ENTITY_TYPE_POST, discussPost.getId());
                post.put("likeCount",likeCount);
                discussPostVo.add(post);
            }
        }
        model.addAttribute("discussPosts",discussPostVo);
        model.addAttribute("postCount",postCount);

        return "site/my-post";
    }

    @RequestMapping(value = {"/myReply/{userId}"},method = RequestMethod.GET)
    public String myReply(@PathVariable("userId") int userId, Model model, Page page){
        User user = userService.selectById(userId);
        model.addAttribute("user",user);

        //分页信息
        //使用USER类型，entityId被userId赋值
        int replyCount = commentService.selectCommentRows(ENTITY_TYPE_USER,userId);
        page.setRows(replyCount);
        page.setPath("/user/myReply/" + userId);
        page.setLimit(5);

        //显示评论
        List<Comment> comments = commentService.selectCommentsByEntity(ENTITY_TYPE_USER, userId, page.getOffset(), page.getLimit());
        List<Map<String,Object>> commentVo = new ArrayList<>();
        //添加目标帖子信息
        if(comments!=null){
            for (Comment comment : comments) {
                Map<String,Object> map = new HashMap<>();
                map.put("comment",comment);
                DiscussPost discussPost = discussPostService.selectDiscussPost(comment.getEntityId());
                map.put("post",discussPost);
                commentVo.add(map);
            }
        }
        model.addAttribute("comments",commentVo);
        model.addAttribute("replyCount",replyCount);

        return "site/my-reply";
    }

}
