import Web from "./Web";

export default Web