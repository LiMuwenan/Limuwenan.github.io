package com.edu.ligen.nowcoder.dao;

import com.edu.ligen.nowcoder.entity.LoginTicket;
import org.apache.ibatis.annotations.Mapper;

@Mapper
@Deprecated
public interface LoginTicketMapper {

    //根据凭证找出所有信息
    LoginTicket selectByTicket(String ticket);

    //插入新凭证
    int insertLoginTicket(LoginTicket loginTicket);

    //更新凭证相关信息
    int updateLoginTicket(String ticket, int status);


    //删除凭证
    //真正的工程开发很少删除数据，只会让其失效
    int deleteLoginTicket(String ticket);
}
