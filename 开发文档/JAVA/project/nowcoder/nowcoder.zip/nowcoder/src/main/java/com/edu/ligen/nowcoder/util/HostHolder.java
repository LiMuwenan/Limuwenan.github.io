package com.edu.ligen.nowcoder.util;

import com.edu.ligen.nowcoder.entity.User;
import org.springframework.stereotype.Component;

/**
 * 持有用户信息，代替session对象，多线程安全
 */
@Component
public class HostHolder {

    private ThreadLocal<User>  users = new ThreadLocal<>();

    public void setValue(User user){
        users.set(user);
    }

    public User getValue(){
        return users.get();
    }

    public void remove(){
        users.remove();
    }
}
