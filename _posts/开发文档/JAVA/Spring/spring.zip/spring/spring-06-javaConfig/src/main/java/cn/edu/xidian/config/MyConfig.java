package cn.edu.xidian.config;


import cn.edu.xidian.domain.User;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MyConfig {

    @Bean
    public User getUserBean(){
        return new User();
    }

}
