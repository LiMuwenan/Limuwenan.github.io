package com.edu.ligen.nowcoder.controller;

import com.edu.ligen.nowcoder.annotation.LoginRequired;
import com.edu.ligen.nowcoder.entity.Event;
import com.edu.ligen.nowcoder.entity.Page;
import com.edu.ligen.nowcoder.entity.User;
import com.edu.ligen.nowcoder.event.EventProducer;
import com.edu.ligen.nowcoder.service.FollowService;
import com.edu.ligen.nowcoder.service.UserService;
import com.edu.ligen.nowcoder.util.CommunityConstant;
import com.edu.ligen.nowcoder.util.CommunityUtils;
import com.edu.ligen.nowcoder.util.HostHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;
import java.util.Map;

@Controller
public class FollowController implements CommunityConstant {

    @Autowired
    private HostHolder hostHolder;

    @Autowired
    private FollowService followService;

    @Autowired
    private UserService userService;

    @Autowired
    private EventProducer eventProducer;

    @RequestMapping(value = "/follow",method = RequestMethod.POST)
    @ResponseBody
    @LoginRequired
    public String follow(int entityType,int entityId){
        User user = hostHolder.getValue();

        followService.follow(user.getId(),entityType,entityId);

        //触发关注事件
        Event event = new Event()
                .setTopic(TOPIC_FOLLOW)
                .setUserId(user.getId())
                .setEntityType(entityType)
                .setEntityId(entityId)
                .setEntityUserId(entityId);
        eventProducer.fireEvent(event);

        return CommunityUtils.getJSONString(0,"已关注");
    }

    @RequestMapping(value = "/unfollow",method = RequestMethod.POST)
    @ResponseBody
    @LoginRequired
    public String unfollow(int entityType,int entityId){
        User user = hostHolder.getValue();

        followService.unfollow(user.getId(),entityType,entityId);

        return CommunityUtils.getJSONString(0,"已取消关注");
    }

    @RequestMapping(value = {"/followee/{userId}","/followee.html/{userId}"},method = RequestMethod.GET)
    public String getFollowee(@PathVariable("userId") int userId, Model model, Page page){
        User user = userService.selectById(userId);
        if(user==null){
            throw new RuntimeException("该用户不存在!");
        }
        model.addAttribute("user",user);

        //设置分页
        page.setLimit(5);
        page.setPath("/followee" + userId);
        page.setRows((int)(followService.selectFolloweeCount(userId,ENTITY_TYPE_USER)));

        List<Map<String,Object>> userList = followService.selectFollowees(userId, page.getOffset(),page.getLimit());
        if(userList!=null){
            for (Map<String, Object> map : userList) {
                User u = (User) map.get("user");
                //要查当前用户是否也关注了u用户
                map.put("isFollowed",isFollowed(u.getId()));
            }
        }
        model.addAttribute("users",userList);

        return "site/followee";
    }

    @RequestMapping(value = {"/follower/{userId}","/follower.html/{userId}"},method = RequestMethod.GET)
    public String getFollower(@PathVariable("userId") int userId,Model model, Page page){
        User user = userService.selectById(userId);
        if(user==null){
            throw new RuntimeException("该用户不存在!");
        }
        model.addAttribute("user",user);

        //设置分页
        page.setLimit(5);
        page.setPath("/follower" + userId);
        page.setRows((int)(followService.selectFollowerCount(ENTITY_TYPE_USER,userId)));

        List<Map<String,Object>> userList = followService.selectFollowers(userId, page.getOffset(),page.getLimit());
        if(userList!=null){
            for (Map<String, Object> map : userList) {
                User u = (User) map.get("user");
                //要查当前用户是否也关注了u用户
                map.put("isFollowed",isFollowed(u.getId()));
            }
        }
        model.addAttribute("users",userList);
        return "site/follower";
    }

    private boolean isFollowed(int targetId){
        if(hostHolder.getValue()==null){
            return false;
        }
        return followService.isFollowed(hostHolder.getValue().getId(), ENTITY_TYPE_USER,targetId);
    }
}
