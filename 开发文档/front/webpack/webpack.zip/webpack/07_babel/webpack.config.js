const path = require("path")
const HtmlWebpackPlugin = require('html-webpack-plugin')
const MiniCssExtractPlugin = require('mini-css-extract-plugin')
const CssMinimizerPlugin = require('css-minimizer-webpack-plugin')

module.exports = {
    // 入口
    entry: "./src/index.js",
    // 输出
    output: {
        // 文件输出路径
        path: path.resolve(__dirname, "dist"),
        // 文件名
        filename: "main.js",
        // 清理之前的打包内容
        clean: true,
        // 资源文件输出路径
        // 根据文件内容生成文件名，扩展名使用原扩展名
        // assetModuleFilename: "images/[contenthash][ext]"
    },
    devtool: 'inline-source-map',
    // 加载器
    module:  {
        rules: [
            // loader的配置
            {
                test: /\.js$/,
                exclude: /node_modules/,
                use: {
                  loader: 'babel-loader',
                  options: {
                      presets: ['@babel/preset-env'],
                  },
                },
            },
            {
                test: /\.css$/,
                use: [
                    MiniCssExtractPlugin.loader,
                    'css-loader', // 遵循从下到上的加载原则
                ]
            },
            {
                test: /\.png$/, // png文件
                type: "asset/resource",
                generator: {
                    filename: 'images/[contenthash][ext]'
                }
            },
            {
                test: /\.svg$/, // svg
                type: "asset/source",
            },
            {
                test: /\.txt$/, // txt
                type: "asset/source",
            },
            {
                test: /\.jpg$/,
                type: "asset",
                generator: {
                    filename: 'images/[contenthash][ext]'
                },
                parser: {
                    dataUrlCondition: {
                        maxSize: 4 * 1024, // 自定义转换大小
                    },
                },
            }

        ]
    },
    // 插件
    plugins: [
        // plugins配置
        new HtmlWebpackPlugin({
            template: './public/index.html', // 从哪个文件生成
            filename: 'app.html', // 输出文件的名称
            inject: 'body', // 生成的代码放在模板的哪个标签中
        }),
        new MiniCssExtractPlugin({
           filename: 'styles/css/[contenthash].css',
        }),
    ],
    // 优化
    // optimization: {
    //     minimizer: [
    //         // css压缩
    //         new CssMinimizerPlugin(),
    //     ]
    // },
    // 模式
    mode: "development",
}