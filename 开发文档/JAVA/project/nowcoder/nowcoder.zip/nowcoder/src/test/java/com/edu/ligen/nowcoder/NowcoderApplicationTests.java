package com.edu.ligen.nowcoder;

import com.edu.ligen.nowcoder.entity.DiscussPost;
import com.edu.ligen.nowcoder.service.DiscussPostService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Date;

@SpringBootTest
class NowcoderApplicationTests {

    @Autowired
    private DiscussPostService postService;

    private DiscussPost data;

//    @Test
//    public void caffeineTest(){
//        for (int i = 0; i < 300000; i++) {
//            DiscussPost post = new DiscussPost();
//            post.setUserId(111);
//            post.setTitle("互联网求职");
//            post.setContent("互联网哈活动哈哈");
//            post.setCreateTime(new Date());
//            post.setScore(Math.random()*2000);
//            postService.insertDiscussPost(post);
//        }
//    }
//
//    @Test
//    public void testCache(){
//        System.out.println(postService.selectDiscussPosts(0,0,10,1));
//        System.out.println(postService.selectDiscussPosts(0,0,10,1));
//        System.out.println(postService.selectDiscussPosts(0,0,10,1));
//        System.out.println(postService.selectDiscussPosts(0,0,10,0));
//    }

    @BeforeEach
    public void beforeEach(){
        //初始化测试数据
        data = new DiscussPost();
        data.setUserId(200);
        data.setTitle("互联网求职");
        data.setContent("互联网哈活动哈哈");
        data.setCreateTime(new Date());
        postService.insertDiscussPost(data);
    }

    @AfterEach
    public void afterEach(){
        //清理数据
        postService.updateStatus(data.getUserId(),2);
    }

//    @Test
//    public void testSelectById(){
//        DiscussPost post = postService.selectDiscussPost(data.getUserId());
//        Assertions.assertNotNull(post);
//        Assertions.assertEquals(data.getTitle(),post.getTitle());
//        Assertions.assertEquals(data.getContent(),post.getContent());
//    }
//
//    @Test
//    public void testUpdate(){
//        int rows = postService.updateScore(data.getUserId(),2000.00);
//        Assertions.assertEquals(1,rows);
//
//        DiscussPost post = postService.selectDiscussPost(data.getUserId());
//        Assertions.assertEquals(2000.00,post.getScore(),2);
//    }


}
