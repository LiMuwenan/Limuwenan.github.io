package com.edu.ligen.nowcoder.service.impl;

import com.edu.ligen.nowcoder.service.LikeService;
import com.edu.ligen.nowcoder.util.RedisKeyUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.SessionCallback;
import org.springframework.stereotype.Service;

@Service
public class LikeServiceImpl implements LikeService {

    @Autowired
    private RedisTemplate redisTemplate;

    public void like(int userId,int entityType,int entityId,int entityUserId){
//        String likeKey = RedisKeyUtil.getEntityLikeKey(entityType, entityId);
//        boolean isMember =  redisTemplate.opsForSet().isMember(likeKey,userId);
//        if(isMember){
//            //已经存在则取消点赞
//            redisTemplate.opsForSet().remove(likeKey,userId);
//        }else{
//            redisTemplate.opsForSet().add(likeKey,userId);
//        }

        //添加查询自己的所有点赞功能，进行事务重构
        redisTemplate.execute(new SessionCallback() {
            @Override
            public Object execute(RedisOperations operations) throws DataAccessException {
                String likeKey = RedisKeyUtil.getEntityLikeKey(entityType, entityId);
                String userLikeKey = RedisKeyUtil.getUserLikeKey(entityUserId);

                boolean isMember = redisTemplate.opsForSet().isMember(likeKey,userId);//该用户是否给该帖子、评论、回复点赞
                operations.multi();
                if(isMember){
                   operations.opsForSet().remove(likeKey,userId);
                   operations.opsForValue().decrement(userLikeKey);
                }else{
                    operations.opsForSet().add(likeKey,userId);
                    operations.opsForValue().increment(userLikeKey);
                }

                return operations.exec();
            }
        });
    }

    @Override
    public long selectEntityLikeCount(int entityType, int entityId) {
        String likeKey = RedisKeyUtil.getEntityLikeKey(entityType, entityId);
        return redisTemplate.opsForSet().size(likeKey);
    }

    @Override
    public int selectEntityLikeStatus(int userId, int entityType, int entityId) {
        String likeKey = RedisKeyUtil.getEntityLikeKey(entityType, entityId);
        return redisTemplate.opsForSet().isMember(likeKey,userId) ? 1 : 0;
    }

    @Override
    public int selectUserLikeCount(int userId) {
        String userLikeKey = RedisKeyUtil.getUserLikeKey(userId);
        Integer count = (Integer) redisTemplate.opsForValue().get(userLikeKey);
        return count == null ? 0 : count;
    }
}
