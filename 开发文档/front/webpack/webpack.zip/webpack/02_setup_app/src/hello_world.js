export default function helloWorld() {
    console.log('Hello world')
}