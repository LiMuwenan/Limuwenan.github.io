package com.edu.ligen.nowcoder.controller;

import com.alibaba.fastjson.JSONObject;
import com.edu.ligen.nowcoder.annotation.LoginRequired;
import com.edu.ligen.nowcoder.entity.Message;
import com.edu.ligen.nowcoder.entity.Page;
import com.edu.ligen.nowcoder.entity.User;
import com.edu.ligen.nowcoder.service.MessageService;
import com.edu.ligen.nowcoder.service.UserService;
import com.edu.ligen.nowcoder.util.CommunityConstant;
import com.edu.ligen.nowcoder.util.CommunityUtils;
import com.edu.ligen.nowcoder.util.HostHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.util.HtmlUtils;

import java.util.*;

@Controller
public class MessageController implements CommunityConstant {

    @Autowired
    private MessageService messageService;

    @Autowired
    private UserService userService;

    @Autowired
    private HostHolder hostHolder;

    @RequestMapping(value = {"/letter/list"}, method = RequestMethod.GET)
    @LoginRequired
    public String getLetterList(Model model, Page page) {
        //获取当前用户
        User user = hostHolder.getValue();
        if (user == null) {
            //转到首页登录
            return "redirect:/site/login";
        }
        //分页设置
        page.setPath("/letter/list");
        page.setRows(messageService.selectConversationCount(user.getId()));
        page.setLimit(5);


        List<Message> messageList = messageService.selectConversations(user.getId(), page.getOffset(), page.getLimit());
        List<Map<String, Object>> conversations = new ArrayList<>();
        if (messageList != null) {
            for (Message message : messageList) {
                Map<String, Object> conversation = new HashMap<>();
                conversation.put("conversation", message);
                conversation.put("letterCount", messageService.selectLetterCount(message.getConversationId()));
                conversation.put("unreadCount", messageService.selectLetterUnreadCount(user.getId(), message.getConversationId()));
                int targetId = user.getId() != message.getFromId() ? message.getFromId() : message.getToId();
                User target = userService.selectById(targetId);
                conversation.put("target", target);

                conversations.add(conversation);

            }
        }
        model.addAttribute("conversations", conversations);

        //查询未读消息数量
        int letterUnreadCount = messageService.selectLetterUnreadCount(user.getId(), null);
        model.addAttribute("letterUnreadCount", letterUnreadCount);
        int noticeUnreadCount = messageService.selectUnreadNoticeCount(user.getId(), null);
        model.addAttribute("unreadNoticeCount", noticeUnreadCount);

        return "site/letter";
    }


    @RequestMapping(value = {"/letter/detail/{conversationId}"}, method = RequestMethod.GET)
    public String getLetterDetail(@PathVariable("conversationId") String conversationId, Page page, Model model) {
        User user = hostHolder.getValue();
        //分页信息
        page.setRows(messageService.selectLetterCount(conversationId));
        page.setPath("/letter/detail/" + conversationId);
        page.setLimit(5);

        //从conversationId中获得目标id
        String[] fromto = conversationId.split("_");
        int from = Integer.parseInt(fromto[0]);
        int to = Integer.parseInt(fromto[1]);
        from = user.getId() == from ? to : from;
        User fromUser = userService.selectById(from);

        //私信列表
        List<Message> messageList = messageService.selectLettersByConversationId(conversationId, page.getOffset(), page.getLimit());
        List<Map<String, Object>> letters = new ArrayList<>();

        //设置已读
        List<Integer> ids = new ArrayList<>();

        if (messageList != null) {
            for (Message message : messageList) {
                Map<String, Object> letter = new HashMap<>();
                letter.put("letter", message);
                //如果fromid与from相同，则显示来信方。否则显示自己
                if (message.getFromId() == from) {
                    letter.put("fromUser", fromUser);
                    if (message.getStatus() == 0)
                        ids.add(message.getId());
                } else {
                    letter.put("fromUser", user);
                }

                letters.add(letter);
            }
        }

        if (!ids.isEmpty()) {
            int rows = messageService.updateMessageStatus(ids, 1);
        }


        model.addAttribute("letters", letters);
        model.addAttribute("target", fromUser);
        return "site/letter-detail";
    }

    /**
     * 处理发送消息
     *
     * @param toName
     * @param content
     * @return
     */
    @RequestMapping(value = {"/letter/send"}, method = RequestMethod.POST)
    @ResponseBody
    public String sendMessage(String toName, String content) {
        User toUser = userService.selectByUsername(toName);
        if (toUser == null) {
            return CommunityUtils.getJSONString(1, "目标用户不存在");
        }
        //封装消息
        User user = hostHolder.getValue();
        Message message = new Message();
        message.setFromId(user.getId());
        message.setToId(toUser.getId());
        message.setConversationId(toUser.getId() < user.getId() ? toUser.getId() + "_" + user.getId() : user.getId() + "_" + toUser.getId());
        message.setContent(content);
        message.setStatus(0);
        message.setCreateTime(new Date());

        messageService.insertMessage(message);

        return CommunityUtils.getJSONString(0);
    }

    @RequestMapping(value = {"/letter/delete/{conversationId}/{id}"}, method = RequestMethod.GET)
    public String deleteMessage(@PathVariable("conversationId") String conversationId, @PathVariable("id") int id) {
        messageService.updateMessageStatus(Arrays.asList(id), 2);
        return "redirect:/letter/detail/" + conversationId;
    }

    @RequestMapping(value = {"/notice/list"}, method = RequestMethod.GET)
    public String getNoticeList(Model model) {
        User user = hostHolder.getValue();

        //评论通知
        Message message = messageService.selectLatestNotice(user.getId(), TOPIC_COMMENT);
        if (message != null) {
            Map<String, Object> messageVo = new HashMap<>();
            messageVo.put("message", message);

            String content = HtmlUtils.htmlUnescape(message.getContent());
            Map<String, Object> data = JSONObject.parseObject(content, HashMap.class);
            messageVo.put("user", userService.selectById((Integer) data.get("userId")));
            messageVo.put("entityType", data.get("entityType"));
            messageVo.put("entityId", data.get("entityId"));
            messageVo.put("postId", data.get("postId"));

            int commentCount = messageService.selectNoticeCount(user.getId(), TOPIC_COMMENT);
            messageVo.put("commentCount", commentCount);

            int unreadCount = messageService.selectUnreadNoticeCount(user.getId(), TOPIC_COMMENT);
            messageVo.put("unreadCount", unreadCount);

            model.addAttribute("commentMessage", messageVo);
        }

        //点赞通知
        message = messageService.selectLatestNotice(user.getId(), TOPIC_LIKE);
        if (message != null) {
            Map<String, Object> messageVo = new HashMap<>();
            messageVo.put("message", message);

            String content = HtmlUtils.htmlUnescape(message.getContent());
            Map<String, Object> data = JSONObject.parseObject(content, HashMap.class);
            messageVo.put("user", userService.selectById((Integer) data.get("userId")));
            messageVo.put("entityType", data.get("entityType"));
            messageVo.put("entityId", data.get("entityId"));
            messageVo.put("postId", data.get("postId"));

            int likeCount = messageService.selectNoticeCount(user.getId(), TOPIC_LIKE);
            messageVo.put("likeCount", likeCount);

            int unreadCount = messageService.selectUnreadNoticeCount(user.getId(), TOPIC_LIKE);
            messageVo.put("unreadCount", unreadCount);

            model.addAttribute("likeMessage", messageVo);
        }

        //关注通知
        message = messageService.selectLatestNotice(user.getId(), TOPIC_FOLLOW);
        if (message != null) {
            Map<String, Object> messageVo = new HashMap<>();
            messageVo.put("message", message);

            String content = HtmlUtils.htmlUnescape(message.getContent());
            Map<String, Object> data = JSONObject.parseObject(content, HashMap.class);
            messageVo.put("user", userService.selectById((Integer) data.get("userId")));
            messageVo.put("entityType", data.get("entityType"));
            messageVo.put("entityId", data.get("entityId"));

            int followCount = messageService.selectNoticeCount(user.getId(), TOPIC_FOLLOW);
            messageVo.put("followCount", followCount);

            int unreadCount = messageService.selectUnreadNoticeCount(user.getId(), TOPIC_FOLLOW);
            messageVo.put("unreadCount", unreadCount);

            model.addAttribute("followMessage", messageVo);
        }

        //查询未读数量
        int letterUnreadCount = messageService.selectLetterUnreadCount(user.getId(), null);
        model.addAttribute("letterUnreadCount", letterUnreadCount);
        int noticeUnreadCount = messageService.selectUnreadNoticeCount(user.getId(), null);
        model.addAttribute("unreadNoticeCount", noticeUnreadCount);


        return "site/notice";
    }

    @RequestMapping(value = {"/notice/detail/{topic}"}, method = RequestMethod.GET)
    public String getNoticeDetail(@PathVariable("topic") String topic, Model model, Page page) {
        User user = hostHolder.getValue();
        //设置分页
        page.setPath("/notice/detail/" + topic);
        page.setLimit(5);
        page.setRows(messageService.selectNoticeCount(user.getId(),topic));

        List<Message> notices = messageService.selectNotices(user.getId(), topic, page.getOffset(), page.getLimit());
        List<Map<String,Object>> noticeVoList = new ArrayList<>();
        //设置已读
        List<Integer> ids = new ArrayList<>();

        if(notices!=null){
            for (Message notice : notices) {
                Map<String,Object> map = new HashMap<>();
                map.put("notice",notice);
                String content = HtmlUtils.htmlUnescape(notice.getContent());
                HashMap<String,Object> data = JSONObject.parseObject(content, HashMap.class);
                map.put("user",userService.selectById((Integer) data.get("userId")));
                System.out.println(userService.selectById((Integer) data.get("userId")));
                map.put("entityType",data.get("entityType"));
                map.put("entityId",data.get("entityId"));
                map.put("postId",data.get("postId"));

                noticeVoList.add(map);
                if(notice.getStatus()==0){
                    ids.add(notice.getId());
                }
            }
        }
        model.addAttribute("noticeVoList",noticeVoList);
        model.addAttribute("topic",topic);

        //设置已读
        if(!ids.isEmpty()){
            int rows = messageService.updateMessageStatus(ids, 1);
        }

        return "site/notice-detail";
    }
}
