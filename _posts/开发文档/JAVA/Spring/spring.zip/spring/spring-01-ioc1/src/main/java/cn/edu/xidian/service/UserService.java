package cn.edu.xidian.service;

public interface UserService {
    void getUser();
}
