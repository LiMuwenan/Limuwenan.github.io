package cn.edu.xidian.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/hello")
public class RedirectAndForwardController {

    @RequestMapping("/redirect")
    public String redirect(){

        return "redirect:/hello/isRedirect";//转发到一个请求方法
    }

    @RequestMapping("/isRedirect")
    public String isRedirect(){
        return "redirect";
    }

    @RequestMapping("/forward")
    public String forward(){

        return "forward:/hello/isForward";
    }

    @RequestMapping("/isForward")
    public String isForward(){
        return "forward";
    }
}
