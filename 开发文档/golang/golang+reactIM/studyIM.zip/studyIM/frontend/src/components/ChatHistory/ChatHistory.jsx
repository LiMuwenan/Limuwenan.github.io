import React, {Component} from "react";
import './ChatHistory.scss'
import Message from '../Message/Message'


class ChatHistory extends Component {
    constructor(props) {
        super(props);
        this.state = {
            chatHistory: []
        }
        this.Update = this.Update.bind(this)
    }

    render() {
        console.log("渲染一次ChatHistory");
        let messages = this.state.chatHistory.map((msg) =>
            <Message message = {msg} />
        )
        return (
            <div className = "ChatHistory">
                <h2>Chat History</h2>
                {messages}
            </div>
        )
    }

    Update(msg) {
        console.log("New Message")
        this.setState({
            chatHistory: [...this.state.chatHistory, msg]
        })
    }
}

export default ChatHistory
