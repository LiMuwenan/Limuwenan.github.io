import helloWorld from "./hello_world";
import imgsrc from './assets/logo500x500.png'
import logosvg from './assets/密码.svg'
import txt from './assets/test.txt'
import jpg from './assets/v2-feb6132028564c537dd894dfe82585d7_hd.jpg'

helloWorld()

const img = document.createElement('img')
img.src = imgsrc
document.body.appendChild(img)

const img2 = document.createElement('img')
img2.src = logosvg
document.body.appendChild(img2)

const txt1 = document.createElement('div')
txt1.textContent = txt
document.body.appendChild(txt1)

const img3 = document.createElement('img')
img3.src = jpg
document.body.appendChild(img3)