package cn.edu.xidian.mapper;

import cn.edu.xidian.domain.User;

import java.util.List;

public interface UserMapper {
    List<User> getUserList();
}
