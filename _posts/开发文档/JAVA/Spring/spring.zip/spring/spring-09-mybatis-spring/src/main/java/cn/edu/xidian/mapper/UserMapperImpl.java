package cn.edu.xidian.mapper;

import cn.edu.xidian.domain.User;
import org.mybatis.spring.SqlSessionTemplate;

import java.util.List;

public class UserMapperImpl implements UserMapper{

    //我们所有操作，现在都使用SqlSessionTemplate类

    private SqlSessionTemplate sqlSession;

    public UserMapperImpl(SqlSessionTemplate sqlSession) {
        this.sqlSession = sqlSession;
    }

    public UserMapperImpl() {
    }

    public SqlSessionTemplate getSqlSession() {
        return sqlSession;
    }

    public void setSqlSession(SqlSessionTemplate sqlSession) {
        this.sqlSession = sqlSession;
    }

    @Override
    public List<User> getUserList() {
        //这里可以直接使用SqlSessiontemplate类的方法
        UserMapper userMapper =  sqlSession.getMapper(UserMapper.class);
        return userMapper.getUserList();
    }
}
