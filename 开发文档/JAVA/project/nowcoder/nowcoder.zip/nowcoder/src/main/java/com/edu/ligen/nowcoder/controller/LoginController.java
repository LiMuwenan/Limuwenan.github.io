package com.edu.ligen.nowcoder.controller;

import com.edu.ligen.nowcoder.entity.User;
import com.edu.ligen.nowcoder.service.LoginTicketService;
import com.edu.ligen.nowcoder.service.UserService;
import com.edu.ligen.nowcoder.util.CommunityConstant;
import com.edu.ligen.nowcoder.util.CommunityUtils;
import com.edu.ligen.nowcoder.util.CookieUtils;
import com.edu.ligen.nowcoder.util.RedisKeyUtil;
import com.google.code.kaptcha.Producer;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.imageio.ImageIO;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * 注册，登录，忘记密码，修改密码
 */
@Controller
public class LoginController implements CommunityConstant {

    private final static Logger logger = LoggerFactory.getLogger(LoginController.class);

    @Value("${server.servlet.context-path}")
    private String contextPath;

    @Autowired
    private LoginTicketService loginTicketService;

    @Autowired
    private Producer kaptcha;

    @Autowired
    private UserService userService;

    @Autowired
    private RedisTemplate redisTemplate;

    @RequestMapping(value={"/register","/register.html"},method = RequestMethod.GET)
    public String getRegisterPage(){
        return "site/register";
    }

    @RequestMapping(value={"/login","/login.html"},method = RequestMethod.GET)
    public String getLoginPage(){
        return "site/login";
    }


    /**
     * 对用户的注册表单进行处理
     * @param model
     * @param user
     * @return
     */
    @RequestMapping(value="/signup",method = RequestMethod.POST )
    public String signup(Model model, User user){
        Map<String,Object> map = userService.register(user);
        if(map.isEmpty()){//map为空意味着注册成功
            model.addAttribute("msg","您的账号已经注册成功，请前往邮箱进行激活!");
            model.addAttribute("target","/index.html");//发送给operator-result页面
            return "site/operate-result";
        }else{    //注册失败
            model.addAttribute("usernameMsg",map.get("usernameMsg"));
            model.addAttribute("passwordMsg",map.get("passwordMsg"));
            model.addAttribute("emailMsg",map.get("emailMsg"));
            return "site/register";
        }
    }

    /**
     * 使用RESTful风格传参，进行激活
     * //http://localhost:8080/community/activation/101/code
     * @param model
     * @param userId
     * @param activationCode
     * @return
     */
    @RequestMapping(value="/activation/{userId}/{activationCode}",method=RequestMethod.GET)
    public String avtivation(Model model, @PathVariable("userId") int userId,@PathVariable("activationCode") String activationCode){
        int result = userService.activation(userId,activationCode);
        if(result == ACTIVATION_SUCCESS){
            //激活成功，从结果页面返回到登录页
            model.addAttribute("msg","您的账号已经激活成功,可以正常使用了!");
            model.addAttribute("target","/login");
        }else if(result == ACTIVATION_FAILED){
            //激活失败，从结果页面返回首页
            model.addAttribute("msg","很遗憾！激活失败，请您重新检查！");
            model.addAttribute("target","/index");
        }else{
            //重复激活，从结果页面返回到登录页
            model.addAttribute("msg","您的账号已经激活成功,请勿重复激活！");
            model.addAttribute("target","/login");
        }
        return "site/operate-result";
    }

    /**
     * 获取验证码单独写一个请求，方便后面刷新验证码，用response单独返回
     * 该验证码属于敏感信息，所以使用session存储在服务端
     * @param response
     * @param session 使用session保存验证码凭证，重构后不需要session
     */
    @RequestMapping(value = "/kaptcha",method = RequestMethod.GET)
    public void getKaptcha(HttpServletResponse response/*, HttpSession session*/){
        //生成验证码
        String text = kaptcha.createText();
        BufferedImage image = kaptcha.createImage(text);

//        //将验证码存入session
//        session.setAttribute("kaptcha",text);

        //生成用户识别凭证，存至cookie
        String kaptchaOwner = CommunityUtils.generateUUID();
        Cookie cookie = new Cookie("kaptchaOwner",kaptchaOwner);
        cookie.setMaxAge(60);//设置过期时间,60秒
        cookie.setPath(contextPath);
        response.addCookie(cookie);

        //将凭证存入redis
        String kaptchaKey = RedisKeyUtil.getKaptchaKey(kaptchaOwner);
        redisTemplate.opsForValue().set(kaptchaKey,text,60, TimeUnit.SECONDS);

        // 将图片输出给浏览器
        response.setContentType("image/png");
        try(
                OutputStream os = response.getOutputStream();
                ) {
            ImageIO.write(image,"png",os);
        } catch (IOException e) {
            logger.error("验证码响应失败"+e.getMessage());
        }
    }

    /**
     * 对登录进行验证
     * @param username
     * @param password
     * @param verifycode 验证码
     * @param model
     * @param rememberme 是否记住登录
     * @return
     */
    @RequestMapping(value = "/login",method = RequestMethod.POST)
    public String login(String username, String password, String verifycode,
                        Model model, boolean rememberme,
                        HttpServletResponse response,
                        HttpServletRequest request/*,HttpSession session*/){

        logger.info("username==>{}",username);
        logger.info("password==>{}",password);
        logger.info("verifycode==>{}",verifycode);
        //检查验证码
//        String kaptcha = (String) session.getAttribute("kaptcha");
        String kaptcha = "";
        String kaptchaOwner = CookieUtils.getValue(request, "kaptchaOwner");
        if(StringUtils.isNotBlank(kaptchaOwner)){
            //有该凭证
            String kaptchaKey = RedisKeyUtil.getKaptchaKey(kaptchaOwner);
            kaptcha = (String) redisTemplate.opsForValue().get(kaptchaKey);
        }

        if(StringUtils.isBlank(kaptcha) || StringUtils.isBlank(verifycode) || !kaptcha.equalsIgnoreCase(verifycode)){
            model.addAttribute("verifycodeMsg","验证码错误");
            return "site/login";
        }

        //检查账号
        long expiredSeconds = rememberme ? REMEMBER_EXPTRED : DEFAULT_EXPIRED;
        Map<String, Object> map = loginTicketService.login(username, password, expiredSeconds);

        if(map.containsKey("ticket")){//成功
            Cookie cookie = new Cookie("ticket",map.get("ticket").toString());
            cookie.setPath(contextPath);
            cookie.setMaxAge((int) expiredSeconds);
            response.addCookie(cookie);
            return "redirect:index";
        }else{//失败
            model.addAttribute("usernameMsg",map.get("usernameMsg"));
            model.addAttribute("passwordMsg",map.get("passwordMsg"));
            return "site/login";
        }
    }

    /**
     * 注销登录请求
     * @param ticket
     * @return
     */
    @RequestMapping(value = "/logout",method = RequestMethod.GET)
    public String logout(@CookieValue("ticket") String ticket){
        loginTicketService.updateLoginTicket(ticket,1);
        SecurityContextHolder.clearContext();
        return "redirect:/login";
    }

    /**
     * 跳转到忘记密码页面
     * @return
     */
    @RequestMapping(value = {"/forget","/forget.html"},method = RequestMethod.GET)
    public String getForgetPage(){
        return "/site/forget";
    }

    /**
     * 发送验证码请求
     * @param email 接收邮箱，用于给这个邮箱发送验证码
     * @param session 将验证码存入session，方法取用
     * @return
     */
    @RequestMapping(value = "/send",method = RequestMethod.GET)
    @ResponseBody
    public String generterVerifyCode(String email,HttpSession session){
        //直接生成一个6位的数字验证码并且发送到邮箱
        int status = userService.sendResetEmail(email,session);

        return String.valueOf(status);
    }

    /**
     * ajax验证邮箱
     * @param email
     * @return
     */
    @RequestMapping(value = "/email",method = RequestMethod.GET)
    @ResponseBody
    public String emailIsValide(String email){
        User user = userService.selectByEmail(email);
        String emailMsg = "";
        if(user==null){
            emailMsg = "invalid";
        }else{
            emailMsg = "valid";
        }
        return emailMsg;
    }

    /**
     * 对验证码进行验证并修改密码
     * @param email
     * @param verifycode
     * @param password
     * @param session
     * @param model
     * @return
     */
    @RequestMapping(value = "/reset",method = RequestMethod.POST)
    public String resetPassword(String email,String verifycode,String password,
                                HttpSession session,Model model){
        int status = userService.resetPassword(email, verifycode, password, session);
        session.removeAttribute("verifycodeCreateTime");
        session.removeAttribute("verifycode");
        if(status==VERIFYCODE_OVERTIME){
            //失效失败
            model.addAttribute("verifycodeMsg","验证码已失效，请重新获取");
            return "/site/forget";
        }else if(status == VERIFYCODE_ERROR){
            //错误失败
            model.addAttribute("verifycodeMsg","验证码错误");
            return "/site/forget";
        }else{
            return "/site/login";
        }

    }

}
