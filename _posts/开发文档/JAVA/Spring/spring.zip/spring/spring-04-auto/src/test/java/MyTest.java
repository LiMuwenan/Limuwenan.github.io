import cn.edu.xidian.domain.Person;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MyTest {
    public static void main(String[] args) {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        Person person = (Person) context.getBean("person");
        person.getCat().speak();
        person.getDog3().speak();
        person.getDog4().speak();
    }
}
