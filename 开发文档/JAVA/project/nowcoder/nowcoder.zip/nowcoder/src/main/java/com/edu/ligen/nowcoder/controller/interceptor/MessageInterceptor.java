package com.edu.ligen.nowcoder.controller.interceptor;

import com.edu.ligen.nowcoder.entity.User;
import com.edu.ligen.nowcoder.service.MessageService;
import com.edu.ligen.nowcoder.util.HostHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@Component
public class MessageInterceptor implements HandlerInterceptor {

    @Autowired
    private HostHolder hostHolder;

    @Autowired
    private MessageService messageService;

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        User user = hostHolder.getValue();
        if (user != null && modelAndView != null) {
            int letterUnreadCount = messageService.selectLetterUnreadCount(user.getId(), null);
            int noticeUnreadCount = messageService.selectUnreadNoticeCount(user.getId(), null);
            modelAndView.addObject("allUnreadCount", letterUnreadCount + noticeUnreadCount);
        }
    }
}
