package cn.edu.xidian.domain;

public class Cat {
    public void speak(){
        System.out.println("miao");
    }
}
