package com.edu.ligen.nowcoder.util;

import org.apache.commons.lang3.CharUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

/**
 * 敏感词过滤器
 */
@Component
public class SensitiveFilter {

    private static final Logger logger = LoggerFactory.getLogger(SensitiveFilter.class);

    //替换符
    private static final String REPLEACEMENT = "***";

    private TrieNode root = new TrieNode();

    //该注解意思是：该方法在构造器执行后就会被执行
    //系统启动Filter类被加入容器初始化，同时会构造TrieNode，构造完后调用init
    @PostConstruct
    public void init(){

        try(
                InputStream fis = this.getClass().getClassLoader().getResourceAsStream("sensitive-words.txt");
                //字节流转字符流，字符流转缓冲流
                BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
                ){
                String keyword;
                while((keyword = reader.readLine() )!=null){
                    //添加到前缀树
                    this.addKeyword(keyword);
                }
        }catch(IOException e){
            logger.error("敏感词文件读取失败"+e.getMessage());
        }

    }

    //将一个敏感词添加到前缀树中
    private void addKeyword(String keyword){
        TrieNode tmpNode = root;
        for (int i = 0; i < keyword.length(); i++) {
            char c = keyword.charAt(i);
            TrieNode subNode = tmpNode.getSubNode(c);
            if(subNode == null){
                subNode = new TrieNode();
                tmpNode.addSubNode(c,subNode);

                //默认都是尾部，当有孩子节点被加入，则设置为false，不是尾部
                tmpNode.setKeywordEnd(false);
            }

            tmpNode = subNode;
        }
    }

    /**
     * 过滤敏感词
     * @param text 待过滤文本
     * @return 过滤后的文本
     */
    public String filter(String text){
        if(StringUtils.isBlank(text)){
            return null;
        }
        //指针1，指向前缀树的节点
        TrieNode node = root;//开始在根节点
        //指针2，3，用来遍历字符串
        int begin = 0,index = 0;
        //过滤结果
        StringBuilder sb = new StringBuilder();
        //遍历字符串过滤
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            sb.append(c);
            if(isSymbol(c)){
                //是特殊字符，直接跳过
                continue;
            }
            TrieNode tmpNode = node.getSubNode(c);
            begin = i;
            for(index = begin+1;index<text.length()&&tmpNode!=null;index++){
                if(isSymbol(text.charAt(index))){
                    //是特殊字符，直接跳过
                    continue;
                }
                tmpNode = tmpNode.getSubNode(text.charAt(index));
                if(tmpNode!=null && tmpNode.isKeywordEnd()){
                    sb.deleteCharAt(sb.length()-1);
                    sb.append(REPLEACEMENT);
                    node = root;
                    i=index;
                    break;
                }
            }

        }

        return sb.toString();
    }

    /**
     * 判断是否为特殊符号（用户可能通过特殊符号规避敏感词过滤）
     * @param c
     * @return
     */
    private boolean isSymbol(Character c){
        //是不是Ascii码字符，
        //0x2E80--0x9FFF 该范围是东亚文字范围
        return !CharUtils.isAsciiAlphanumeric(c);
    }

    //前缀树
    private class TrieNode{
        //关键词结束标记，是末尾
        private boolean isKeywordEnd =true;

        //孩子节点
        private Map<Character,TrieNode> childNodes = new HashMap<>();

        public boolean isKeywordEnd(){
            return this.isKeywordEnd;
        }

        public void setKeywordEnd(boolean keywordEnd){
            this.isKeywordEnd = keywordEnd;
        }

        //添加子节点
        public void addSubNode(Character c,TrieNode node){
            childNodes.put(c,node);
        }

        //获取子节点
        public TrieNode getSubNode(Character c){
            return childNodes.get(c);
        }
    }

}
