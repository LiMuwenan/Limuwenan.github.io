import cn.edu.xidian.config.MyConfig;
import cn.edu.xidian.domain.User;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MyTest {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(MyConfig.class);

        User user = (User) context.getBean("getUserBean");

        System.out.println(user);
    }
}
