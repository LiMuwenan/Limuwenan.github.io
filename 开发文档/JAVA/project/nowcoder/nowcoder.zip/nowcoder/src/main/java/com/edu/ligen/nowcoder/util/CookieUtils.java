package com.edu.ligen.nowcoder.util;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

public class CookieUtils {

    /**
     * 通过key值从cookie中取得对应数据
     * @param request
     * @param key
     * @return 数据字符串
     */
    public static String getValue(HttpServletRequest request, String key ){
        //参数为空抛出异常
        if(request == null || key == null){
            throw new IllegalArgumentException("参数为空");
        }
        Cookie[] cookies = request.getCookies();
        if(cookies!=null){
            for (Cookie cookie:cookies) {
                if(cookie.getName().equals(key)){
                    return cookie.getValue();
                }
            }
        }
        return null;
    }
}
