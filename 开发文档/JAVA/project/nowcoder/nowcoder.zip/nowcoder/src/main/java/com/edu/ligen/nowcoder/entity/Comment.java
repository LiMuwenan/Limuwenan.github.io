package com.edu.ligen.nowcoder.entity;

import java.util.Date;

public class Comment {

    /**
     *  `id` int(11) NOT NULL AUTO_INCREMENT,
     *   `user_id` int(11) DEFAULT NULL,
     *   `entity_type` int(11) DEFAULT NULL, # 什么类型的评论（给视频？课程？帖子？帖子下的回复？）
     *   `entity_id` int(11) DEFAULT NULL, # 该类型的id
     *   `target_id` int(11) DEFAULT NULL,
     *   `content` content,
     *   `status` int(11) DEFAULT NULL,
     *   `create_time` timestamp NULL DEFAULT NULL,
     */

    private int id;
    private int userId;
    private int entityType;
    private int entityId;
    private int targetId;//指向性回复，给谁回复的
    private String content;
    private int status;//0普通 1精华 2拉黑
    private Date createTime;

    public Comment() {
    }

    public Comment(int id, int userId, int entityType, int entityId, int targetId, String content, int status, Date createTime) {
        this.id = id;
        this.userId = userId;
        this.entityType = entityType;
        this.entityId = entityId;
        this.targetId = targetId;
        this.content = content;
        this.status = status;
        this.createTime = createTime;
    }

    @Override
    public String toString() {
        return "Comment{" +
                "id=" + id +
                ", userId=" + userId +
                ", entityType=" + entityType +
                ", entityId=" + entityId +
                ", targetId=" + targetId +
                ", content='" + content + '\'' +
                ", status=" + status +
                ", createTime=" + createTime +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getEntityType() {
        return entityType;
    }

    public void setEntityType(int entityType) {
        this.entityType = entityType;
    }

    public int getEntityId() {
        return entityId;
    }

    public void setEntityId(int entityId) {
        this.entityId = entityId;
    }

    public int getTargetId() {
        return targetId;
    }

    public void setTargetId(int targetId) {
        this.targetId = targetId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}
